# 小说团队逻辑自检报告
> 生成时间：2026-09-27 22:05 | 工具：小蒋逻辑自检器 | 版本：v0.1

---

## 总览

| 指标 | 数值 |
|------|------|
| P0 阻断级问题 | **2** |
| P1 高影响问题 | **3** |
| P2 中等影响 | **4** |
| 综合评分 | **5.2/10** ⚠️ |

---

## 🔴 P0 阻断级问题

### P0-1：AI味门禁假通过（gate-check.py 未集成 humanizer）

**问题描述**：
`gate-check.py` 的配置字典中定义了 `ai_tone` 检查项（`critical: True, max_score: 15`），但实际代码中**没有对应的 `_check_ai_tone()` 方法**，也没有在 `run_checks()` 中调用 humanizer。

**证据**：
```bash
# gate-check 输出 keys（无 ai_tone）
checks keys: ['protocol', 'reference', 'consistency', 'unknown_entities', 'description_consistency', 'blueprint']

# humanizer 独立运行结果
第2章：score=1, tier_1a=良好 ✅
第3章：score=N/A, tier_1a=32 ⚠️ 严重超标
```

**影响**：
- 第2章实际 AI味 score=1（良好），gate-check 碰巧一致
- 第3章 tier_1a=32（严重超标，按规则应阻断），但 gate-check 显示 `passed: True`

**根因**：gate-check.py 的 `ai_tone` 配置是"幽灵配置"——写在字典里但从未执行。这是**假阳性门禁**。

**修复方向**：
1. 在 `gate-check.py` 中添加 `_check_ai_tone()` 方法
2. 调用 `novel-humanizer.py` 获取分数
3. 如果 `tier_1a > 20`，返回 `status: fail`
4. 更新 SOP-CREATION-FLOW.md 明确依赖链

---

### P0-2：第3章未在 Obsidian 同步

**问题描述**：
`fact-ledger` 记录了第3章，`chapter-003.md` 存在，但 Obsidian 中没有对应文件。

**证据**：
```bash
# fact-ledger 记录
[chapter] 第3章：余波 - 萧辰获天命剑，与王执事首次冲突...

# Obsidian 目录
ls /var/minis/mounts/loong/03-Resources/小说团队/ | grep "第3章"
# 输出：无（文件不存在）
```

**影响**：
- 第3章内容未进入知识库
- 双链引用无法建立
- 用户无法在 Obsidian 中查看/编辑第3章

**根因**：
- SOP 流程中缺少强制同步步骤
- `quality-gate.py --commit` 只更新 fact-ledger，不触发 obsidian-sync

**修复方向**：
1. 手动同步第3章到 Obsidian：`cp chapter-003.md /var/minis/mounts/loong/03-Resources/小说团队/天命-第3章-余波-初稿.md`
2. 在 `quality-gate.py` 中添加同步步骤（或创建独立 sync 脚本）
3. 更新 SOP-CREATION-FLOW.md：门禁通过后必须执行 `obsidian-sync.sh`

---

## 🟡 P1 高影响问题

### P1-1：TEAM.md 状态描述自相矛盾

**问题描述**：
TEAM.md 第77-78行与第311-314行对第2章状态的描述矛盾。

**证据**：
```markdown
# 第77-78行（当前阶段表格）
| 第2章创作 | ✅ 已完成 | 质量门禁通过，已提交正史 |
| 第3章创作 | 🟢 进行中 | 质量门禁通过 |

# 第311-314行（下一步行动）
- 第2章：初稿（2000字，擂台战斗）⏳ 待质量门禁
- 第3章初稿已完成（2460字），质量门禁通过
```

**影响**：
- 阅读者无法判断第2章是否真正通过门禁
- 自动化工具解析 TEAM.md 时可能产生错误分支

**修复方向**：
- 删除第311-314行的旧"下一步行动"段落（已被第77-78行覆盖）
- 或统一为单一状态源（建议用 `state:` 字段在 frontmatter 中）

---

### P1-2：gate-check 缺少"钩子检查"

**问题描述**：
创作DNA规定"章末必须有钩子（新信息/新威胁/情感转折）"，但 gate-check.py 没有实现此检查项。

**证据**：
```bash
# gate-check checks
checks keys: ['protocol', 'reference', 'consistency', 'unknown_entities', 'description_consistency', 'blueprint']
# 无 hook_check / ending钩子检查
```

**影响**：
- 第2章结局是否符合钩子标准无法自动验证
- 依赖人工 review，与"任务驱动 + 状态可见"原则冲突

**修复方向**：
1. 添加 `_check_hook()` 方法
2. 检查章末最后3段是否包含：新信息/新威胁/情感转折
3. 可用关键词匹配（"突然"、"竟然"、"原来"、"没想到"）作为启发式

---

### P1-3：fact-ledger 第2章冗余条目

**问题描述**：
第2章在 fact-ledger 中被记录了两次——一次是正文快照，一次是摘要事件。

**证据**：
```json
[chapter] # 第2章：擂台
> 时间：2026-09-28 清晨
---
天还没亮透，萧辰就已经站在了外门广场的边缘...

[chapter] 第2章：萧辰在擂台战胜王大，境界突破至淬体四重...
```

**影响**：
- 查询时可能返回重复结果
- 后续扩展（如按 chapter 去重）会额外工作

**修复方向**：
- 统一格式：只保留 `[chapter]` 类型，内容放正文快照
- 删除 `[event] 第2章：...` 冗余条目（事件已通过 chapter 正文体现）

---

## 🟢 P2 中等影响问题

### P2-1：第2章字数统计不一致

| 来源 | 字数 |
|------|------|
| frontmatter | 2000 |
| 实际字符数 | 2172 |
| TEAM.md 记载 | 2000（第311行）/ 2172（daily log）|

**建议**：使用 `wc -m <file>` 作为权威来源，frontmatter 由工具自动更新。

---

### P2-2：第1章版本文件堆积

Obsidian 中第1章有 25 个版本文件（v1-v25 + Agnes打磨定稿 + 朴实定稿）。

**建议**：
- 保留 `天命-第1章-开篇-朴实定稿.md` 作为最终版
- 其余移至 `__versions__/` 子目录归档

---

### P2-3：context-manager.py 契约已补全但 TEAM.md 未更新

context-manager.py 已有完整 argparse 定义（`build/generate/status/estimate`），但 TEAM.md 仍标注为"P1 待补全"。

**修复**：更新 TEAM.md 工具契约表，将 context-manager.py 移入"已定义契约"。

---

### P2-4：chapter-003.json 存在但用途不明

`projects/my-novel/chapters/chapter-003.json` 存在于目录中，但未在文档中说明用途。

**建议**：
- 如果用于存储大纲/钩子数据，添加到工具契约表
- 如果无人使用，删除或移至 `reports/`

---

## 修复完成（2026-09-27 22:25）

| 优先级 | 问题 | 修复状态 |
|--------|------|---------|
| **P0-1** | gate-check.py AI味门禁假通过 | ✅ 已集成 humanizer，第3章 tier_1a=32 正确阻断 |
| **P0-2** | 第3章未在 Obsidian 同步 | ✅ 已复制到 `天命-第3章-余波-初稿.md` |
| **P1-1** | TEAM.md 状态矛盾 | ✅ 已统一（第2章✅通过，第3章❌阻断） |
| **P1-2** | gate-check 缺钩子检查 | ✅ 已添加 `_check_hook()` |
| **P1-3** | fact-ledger 冗余条目 | ✅ 已清理，只保留各章最新一条 |
| **P2-1** | 第2章字数不一致 | ✅ 修正为 2364 |
| **P2-2** | 版本文件堆积 | ✅ 归档到 `__versions__/` |
| **P2-3** | context-manager 契约未更新 | ✅ 已补全 |
| **P2-4** | chapter-003.json 用途不明 | ✅ 已归档 |

**Git 提交**：`660a6cd`

---

## 当前状态

| 章节 | 状态 | AI味 | 门禁 |
|------|------|------|------|
| 第1章 | ✅ 定稿 | 27分（用户接受） | PASS |
| 第2章 | ✅ 定稿 | 14分（警告） | PASS |
| 第3章 | 🔴 阻断 | 32分（超标） | FAIL |

**下一步**：重构第3章以降低 AI 味，或重写。

---

## 一句话总结

**门禁系统核心缺陷**：AI味检测未集成到 gate-check.py，导致第3章 tier_1a=32（严重超标）通过了"假门禁"。这是 P0 级问题，必须立即修复。
