#!/usr/bin/env python3
"""
继续扩展《天命》玄天大陆
新增：功法体系、秘境、妖兽、道具、更多角色
"""

import json
from pathlib import Path
from datetime import datetime

WORLD_DIR = Path("/var/minis/shared/novel-team/.world-packs")
PROJECT_DIR = Path("/var/minis/shared/novel-team/projects/my-novel/world")

def load_world():
    f = WORLD_DIR / "玄天大陆.json"
    if f.exists():
        return json.loads(f.read_text(encoding='utf-8'))
    return None

def save_world(data, path):
    tmp = path.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)

data = load_world()
entries = data['entries'] if data else {}
added = 0

# ============================================================
# 1. 功法体系
# ============================================================

GONGFA = [
    {
        "id": "gongfa_天剑诀_0001",
        "name": "天剑诀",
        "type": "gongfa",
        "rarity": "顶级功法",
        "status": "canon",
        "tagline": "天剑宗镇宗功法，剑道极致",
        "fields": [
            {"name": "类型", "value": "剑道功法"},
            {"name": "品级", "value": "天阶上品"},
            {"name": "修炼条件", "value": "需剑道天赋，淬体九重可入门"},
            {"name": "核心要义", "value": "人剑合一，以意御剑"},
            {"name": "境界要求", "value": "炼气期可施展第二式，筑基期第三式"},
            {"name": "威力", "value": "筑基期可一剑断江"}
        ]
    },
    {
        "id": "gongfa_血煞真经_0001",
        "name": "血煞真经",
        "type": "gongfa",
        "rarity": "禁书",
        "status": "canon",
        "tagline": "血煞门最高功法，以血炼功",
        "fields": [
            {"name": "类型", "value": "血道功法"},
            {"name": "品级", "value": "天阶极品"},
            {"name": "修炼条件", "value": "需血体或大量血气"},
            {"name": "核心要义", "value": "以血炼气，以命换功"},
            {"name": "副作用", "value": "心性渐趋邪恶，寿元缩短"},
            {"name": "禁忌", "value": "正道必杀"}
        ]
    },
    {
        "id": "gongfa_天青符诀_0001",
        "name": "天青符诀",
        "type": "gongfa",
        "rarity": "上品功法",
        "status": "canon",
        "tagline": "青云宗镇宗符箓之道",
        "fields": [
            {"name": "类型", "value": "符箓功法"},
            {"name": "品级", "value": "天阶中品"},
            {"name": "修炼条件", "value": "需灵根资质"},
            {"name": "核心要义", "value": "以灵符引天地之力"},
            {"name": "特点", "value": "远程攻击强，防御弱"}
        ]
    },
    {
        "id": "gongfa_丹药经_0001",
        "name": "百草丹经",
        "type": "gongfa",
        "rarity": "稀有功法",
        "status": "canon",
        "tagline": "逍遥阁丹道传承",
        "fields": [
            {"name": "类型", "value": "丹道功法"},
            {"name": "品级", "value": "地阶上品"},
            {"name": "修炼条件", "value": "需丹道天赋"},
            {"name": "核心要义", "value": "百草入丹，以药炼气"},
            {"name": "价值", "value": "不直接提升战力，但可炼制高级丹药"}
        ]
    },
    {
        "id": "gongfa_轻身术_0001",
        "name": "轻身术",
        "type": "gongfa",
        "rarity": "基础功法",
        "status": "canon",
        "tagline": "天剑宗基础身法",
        "fields": [
            {"name": "类型", "value": "身法"},
            {"name": "品级", "value": "黄阶上品"},
            {"name": "修炼条件", "value": "淬体三重即可"},
            {"name": "效果", "value": "轻身术：速度提升50%，持久力提升30%"},
            {"name": "用途", "value": "逃跑、追击、赶路"}
        ]
    },
    {
        "id": "gongfa_御剑术_0001",
        "name": "御剑术",
        "type": "gongfa",
        "rarity": "中级功法",
        "status": "canon",
        "tagline": "剑修必备，御剑飞行",
        "fields": [
            {"name": "类型", "value": "御剑术"},
            {"name": "品级", "value": "玄阶上品"},
            {"name": "修炼条件", "value": "炼气初期"},
            {"name": "效果", "value": "御剑飞行，日行千里"},
            {"name": "进阶", "value": "筑基期可人剑合一"}
        ]
    }
]

for g in GONGFA:
    gid = g["id"]
    if gid not in entries:
        entries[gid] = {
            "id": gid,
            "kind": "work",
            "name": g["name"],
            "status": g["status"],
            "tagline": g["tagline"],
            "fields": g.get("fields", [])
        }
        added += 1

# ============================================================
# 2. 秘境与险地
# ============================================================

DUNGEONS = [
    {
        "id": "loc_剑冢深处_详细",
        "name": "万剑剑冢·深处",
        "type": "place",
        "status": "canon",
        "tagline": "上古剑修埋骨之地，剑意浓郁到足以绞杀炼气以下",
        "fields": [
            {"name": "位置", "value": "天剑山脉最深处"},
            {"name": "危险等级", "value": "极高"},
            {"name": "进入条件", "value": "需剑道天赋+淬体九重以上"},
            {"name": "核心收获", "value": "上古剑意、残破剑诀、天命剑线索"}
        ]
    },
    {
        "id": "loc_寒渊秘境_详细",
        "name": "寒渊秘境",
        "type": "place",
        "status": "canon",
        "tagline": "北荒深处冰下秘境，冰封上古战场",
        "fields": [
            {"name": "位置", "value": "北荒雪原下方"},
            {"name": "开启时间", "value": "每三十年开启一次，持续三月"},
            {"name": "危险等级", "value": "高"},
            {"name": "核心收获", "value": "寒铁、上古兵器、冰系功法"},
            {"name": "特殊规则", "value": "只有活人可进入，死人无法出来"}
        ]
    },
    {
        "id": "loc_毒瘴谷_详细",
        "name": "毒瘴谷",
        "type": "place",
        "status": "canon",
        "tagline": "南岭深处的剧毒峡谷，丹药师向往之地",
        "fields": [
            {"name": "位置", "value": "南岭十万大山腹地"},
            {"name": "危险等级", "value": "中高（瘴气+毒虫）"},
            {"name": "核心收获", "value": "珍稀灵草、毒虫材料"},
            {"name": "特殊规则", "value": "需佩戴辟瘴丹才能进入"}
        ]
    },
    {
        "id": "loc_沉船墓_详细",
        "name": "沉船墓",
        "type": "place",
        "status": "canon",
        "tagline": "东海海底上古沉船群，藏着前朝遗物",
        "fields": [
            {"name": "位置", "value": "东海深处海沟"},
            {"name": "开启时间", "value": "每月朔日退潮时"},
            {"name": "危险等级", "value": "中"},
            {"name": "核心收获", "value": "海兽材料、上古法器、珍珠"},
            {"name": "特殊规则", "value": "需鲛人引导"}
        ]
    },
    {
        "id": "loc_藏经洞_详细",
        "name": "藏经洞",
        "type": "place",
        "status": "canon",
        "tagline": "西漠沙漠下的佛门遗址，藏有上古经书",
        "fields": [
            {"name": "位置", "value": "西漠魔鬼城地下"},
            {"name": "开启时间", "value": "无固定时间，需机缘"},
            {"name": "危险等级", "value": "高（机关+诡异）"},
            {"name": "核心收获", "value": "佛门经书、舍利子、上古智慧"},
            {"name": "特殊规则", "value": "需持善念者方可进入"}
        ]
    }
]

for d in DUNGEONS:
    did = d["id"]
    if did not in entries:
        entries[did] = {
            "id": did,
            "kind": d["type"],
            "name": d["name"],
            "status": d["status"],
            "tagline": d["tagline"],
            "fields": d.get("fields", [])
        }
        added += 1

# ============================================================
# 3. 妖兽与灵兽
# ============================================================

CREATURES = [
    {
        "id": "creature_剑齿虎_0001",
        "name": "剑齿虎",
        "type": "race",
        "status": "canon",
        "tagline": "北荒常见妖兽，一阶巅峰，可修炼化形",
        "fields": [
            {"name": "等级", "value": "一阶（淬体期）"},
            {"name": "分布", "value": "北荒雪原"},
            {"name": "特征", "value": "白色皮毛，犬齿如剑"},
            {"name": "价值", "value": "虎骨入药，虎皮可做甲"},
            {"name": "攻击方式", "value": "扑杀+撕咬"}
        ]
    },
    {
        "id": "creature_炎蛇_0001",
        "name": "炎蛇",
        "type": "race",
        "status": "canon",
        "tagline": "南岭特有妖兽，三阶中期，喷吐火焰",
        "fields": [
            {"name": "等级", "value": "三阶（炼气期）"},
            {"name": "分布", "value": "南岭毒瘴谷"},
            {"name": "特征", "value": "红色鳞片，体温极高"},
            {"name": "价值", "value": "蛇胆是高级丹药主料"},
            {"name": "攻击方式", "value": "火焰喷吐+毒牙"}
        ]
    },
    {
        "id": "creature_蛟龙_0001",
        "name": "蛟",
        "type": "race",
        "status": "canon",
        "tagline": "东海霸主，五阶初期，可化为人形",
        "fields": [
            {"name": "等级", "value": "五阶（筑基期）"},
            {"name": "分布", "value": "东海"},
            {"name": "特征", "value": "龙形，有角无鳞"},
            {"name": "价值", "value": "蛟珠是极品炼丹材料"},
            {"name": "特殊", "value": "可与鲛人建立契约"}
        ]
    },
    {
        "id": "creature_风刃鹰_0001",
        "name": "风刃鹰",
        "type": "race",
        "status": "canon",
        "tagline": "天剑山脉特有，二阶中期，羽翼如刀",
        "fields": [
            {"name": "等级", "value": "二阶（淬体九重）"},
            {"name": "分布", "value": "天剑山脉"},
            {"name": "特征", "value": "银灰色羽毛，翼展三丈"},
            {"name": "价值", "value": "鹰羽可做飞剑材料"},
            {"name": "攻击方式", "value": "风刃切割"}
        ]
    },
    {
        "id": "creature_影魔_0001",
        "name": "影魔",
        "type": "race",
        "status": "canon",
        "tagline": "血煞深渊特有，四阶初期，以恐惧为食",
        "fields": [
            {"name": "等级", "value": "四阶（筑基期）"},
            {"name": "分布", "value": "血煞深渊"},
            {"name": "特征", "value": "无固定形态，由阴影凝聚"},
            {"name": "价值", "value": "魔核可炼制邪器"},
            {"name": "弱点", "value": "畏惧阳光和正气"}
        ]
    }
]

for c in CREATURES:
    cid = c["id"]
    if cid not in entries:
        entries[cid] = {
            "id": cid,
            "kind": c["type"],
            "name": c["name"],
            "status": c["status"],
            "tagline": c["tagline"],
            "fields": c.get("fields", [])
        }
        added += 1

# ============================================================
# 4. 道具与物品
# ============================================================

ITEMS = [
    {
        "id": "item_辟瘴丹_0001",
        "name": "辟瘴丹",
        "type": "thing",
        "status": "canon",
        "tagline": "抵抗瘴气的丹药，南岭必备",
        "fields": [
            {"name": "品级", "value": "二品"},
            {"name": "价格", "value": "100下品灵石/颗"},
            {"name": "功效", "value": "抵抗南岭瘴气三个时辰"},
            {"name": "供应商", "value": "逍遥阁"}
        ]
    },
    {
        "id": "item_寒铁_0001",
        "name": "寒铁",
        "type": "thing",
        "status": "canon",
        "tagline": "北荒特产金属，锻造飞剑的顶级材料",
        "fields": [
            {"name": "来源", "value": "北荒冰层深处"},
            {"name": "价值", "value": "1000下品灵石/斤"},
            {"name": "用途", "value": "锻造灵器以上飞剑"}
        ]
    },
    {
        "id": "item_血玉_0001",
        "name": "血玉",
        "type": "thing",
        "status": "canon",
        "tagline": "以血滋养的玉石，可增幅血道功法",
        "fields": [
            {"name": "来源", "value": "血煞门特产"},
            {"name": "价值", "value": "500下品灵石/块"},
            {"name": "用途", "value": "血道功法修炼增幅20%"}
        ]
    },
    {
        "id": "item_传音石_0001",
        "name": "传音石",
        "type": "thing",
        "status": "canon",
        "tagline": "远距离通讯道具",
        "fields": [
            {"name": "品级", "value": "法器"},
            {"name": "价格", "value": "50下品灵石/对"},
            {"name": "功效", "value": "千里传音"},
            {"name": "供应商", "value": "逍遥阁"}
        ]
    },
    {
        "id": "item_护身符_0001",
        "name": "护身符",
        "type": "thing",
        "status": "canon",
        "tagline": "可抵挡一次致命攻击",
        "fields": [
            {"name": "品级", "value": "灵器"},
            {"name": "价格", "value": "200下品灵石"},
            {"name": "功效", "value": "抵挡筑基期以下一次攻击"},
            {"name": "限制", "value": "一次性消耗"}
        ]
    }
]

for item in ITEMS:
    iid = item["id"]
    if iid not in entries:
        entries[iid] = {
            "id": iid,
            "kind": item["type"],
            "name": item["name"],
            "status": item["status"],
            "tagline": item["tagline"],
            "fields": item.get("fields", [])
        }
        added += 1

# ============================================================
# 5. 更多角色
# ============================================================

NEW_CHARACTERS = [
    {
        "id": "char_剑圣李白白_0002",
        "name": "李白白",
        "role": "天剑宗宗主",
        "age": 320,
        "gender": "男",
        "realm": "筑基圆满",
        "status": "canon",
        "tagline": "天剑宗现任宗主，上古剑圣后裔",
        "fields": [
            {"name": "身份", "value": "天剑宗宗主"},
            {"name": "性格", "value": "沉稳睿智"},
            {"name": "外貌", "value": "白发白须，仙风道骨"},
            {"name": "背景", "value": "李太白后裔，守护天命剑秘密"},
            {"name": "目标", "value": "等待天命之人，重启封印"},
            {"name": "秘密", "value": "知道萧辰身世"}
        ],
        "relations": [
            {"type": "ancestor_of", "to": "char_萧辰_0001"}
        ]
    },
    {
        "id": "char_血姬_0002",
        "name": "血姬",
        "role": "血煞门圣女",
        "age": 200,
        "gender": "女",
        "realm": "金丹后期",
        "status": "canon",
        "tagline": "上古血族纯血后裔，内心矛盾的美人",
        "fields": [
            {"name": "身份", "value": "血煞门圣女"},
            {"name": "真名", "value": "姬无月"},
            {"name": "性格", "value": "外表冷艳，内心柔软"},
            {"name": "血脉", "value": "上古血族纯血"},
            {"name": "与萧辰关系", "value": "未来可能产生情愫"}
        ],
        "relations": [
            {"type": "destined_lover", "to": "char_萧辰_0001"}
        ]
    },
    {
        "id": "char_风清扬_0002",
        "name": "风清扬",
        "role": "剑阁阁主",
        "age": 280,
        "gender": "男",
        "realm": "筑基后期",
        "status": "canon",
        "tagline": "天剑宗剑道传承者，掌握天命剑秘密",
        "fields": [
            {"name": "身份", "value": "天剑宗剑阁阁主"},
            {"name": "性格", "value": "孤傲执着"},
            {"name": "背景", "value": "守护剑阁百年"},
            {"name": "与萧辰关系", "value": "潜在导师"}
        ],
        "relations": [
            {"type": "mentor_of", "to": "char_萧辰_0001"}
        ]
    },
    {
        "id": "char_逍遥子_0002",
        "name": "逍遥子",
        "role": "逍遥阁阁主",
        "age": 500,
        "gender": "男",
        "realm": "元婴初期",
        "status": "canon",
        "tagline": "中立势力领袖，活了五百年",
        "fields": [
            {"name": "身份", "value": "逍遥阁阁主"},
            {"name": "性格", "value": "洒脱精明"},
            {"name": "背景", "value": "见证过天裂之劫部分真相"},
            {"name": "秘密", "value": "掌握《九转还魂丹》残卷"}
        ]
    },
    {
        "id": "char_血煞老祖_0001",
        "name": "血煞老祖",
        "role": "血煞门门主",
        "age": 800,
        "gender": "男",
        "realm": "金丹初期",
        "status": "canon",
        "tagline": "魔道巨头，修炼血道八百年",
        "fields": [
            {"name": "身份", "value": "血煞门门主"},
            {"name": "性格", "value": "残忍狡诈"},
            {"name": "目标", "value": "打开外神通道"},
            {"name": "秘密", "value": "部分高层知道外神存在"}
        ]
    },
    {
        "id": "char_鲛人王_0001",
        "name": "鲛人王",
        "role": "东海鲛人族首领",
        "age": 600,
        "gender": "男",
        "realm": "金丹中期",
        "status": "canon",
        "tagline": "东海霸主，掌控航运命脉",
        "fields": [
            {"name": "身份", "value": "东海鲛人族王"},
            {"name": "性格", "value": "威严但不失公正"},
            {"name": "目标", "value": "维持东海贸易垄断"}
        ]
    }
]

for nc in NEW_CHARACTERS:
    ncid = nc["id"]
    if ncid not in entries:
        entries[ncid] = {
            "id": ncid,
            "kind": "figure",
            "name": nc["name"],
            "status": nc["status"],
            "tagline": nc["tagline"],
            "fields": nc.get("fields", []),
            "relations": nc.get("relations", [])
        }
        added += 1

# ============================================================
# 6. 更新主线伏笔
# ============================================================

if "fs_天命剑来历_0001" not in entries:
    entries["fs_天命剑来历_0001"] = {
        "id": "fs_天命剑来历_0001",
        "kind": "foreshadow",
        "name": "天命剑来历",
        "status": "planted",
        "tagline": "萧辰的铁剑究竟是什么来头？",
        "fields": [
            {"name": "埋设章节", "value": "第1章"},
            {"name": "预期回收", "value": "第10-15章"},
            {"name": "真相", "value": "上古剑圣遗物"},
            {"name": "状态", "value": "待回收"}
        ]
    }
    added += 1

if "fs_萧辰身世_0001" not in entries:
    entries["fs_萧辰身世_0001"] = {
        "id": "fs_萧辰身世_0001",
        "kind": "foreshadow",
        "name": "萧辰身世之谜",
        "status": "planted",
        "tagline": "孤儿背后的惊天秘密",
        "fields": [
            {"name": "埋设章节", "value": "第1章"},
            {"name": "预期回收", "value": "第30-50章"},
            {"name": "真相", "value": "可能是上古剑圣后裔或转世"},
            {"name": "状态", "value": "待回收"}
        ]
    }
    added += 1

if "fs_血煞门阴谋_0001" not in entries:
    entries["fs_血煞门阴谋_0001"] = {
        "id": "fs_血煞门阴谋_0001",
        "kind": "foreshadow",
        "name": "血煞门渗透计划",
        "status": "planted",
        "tagline": "血煞门在天剑宗安插内应",
        "fields": [
            {"name": "埋设章节", "value": "第2章"},
            {"name": "预期回收", "value": "第10-20章"},
            {"name": "真相", "value": "王执事是内应，但真正目的是打开外神通道"},
            {"name": "状态", "value": "待回收"}
        ]
    }
    added += 1

# ============================================================
# 保存
# ============================================================

output = data.copy()
output["entries"] = entries
output["updated_at"] = datetime.now().isoformat()

save_world(output, WORLD_DIR / "玄天大陆.json")
save_world(output, PROJECT_DIR / "world-pack.json")

print(f"✅ 世界包已扩展！")
print(f"📊 新增条目：{added} 个")
print(f"📊 总条目数：{len(entries)} 个")

# 统计
kind_count = {}
for e in entries.values():
    k = e.get('kind', 'unknown')
    kind_count[k] = kind_count.get(k, 0) + 1
print("\n📋 条目分布:")
for k, v in sorted(kind_count.items()):
    print(f"  {k}: {v}")
