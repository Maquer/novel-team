#!/usr/bin/env python3
"""
修正武力值体系：高层境界差距拉大
"""

import json
from pathlib import Path
from datetime import datetime

WORLD_DIR = Path("/var/minis/shared/novel-team/.world-packs")

def load_world():
    f = WORLD_DIR / "玄天大陆.json"
    if f.exists():
        return json.loads(f.read_text(encoding='utf-8'))
    return None

data = load_world()
entries = data['entries'] if data else {}

# ============================================================
# 修正后的武力值体系：大境界差距5-10倍
# ============================================================

POWER_SYSTEM = {
    "id": "power_武力量化_0001",
    "kind": "power",
    "name": "武力值量化体系",
    "status": "canon",
    "tagline": "标准化战力数值，大境界差距5-10倍，符合'绝对压制'设定",
    "fields": [],
    "system": {
        "基础武力值公式": "武力值 = 境界系数 × 体质加成 × 功法加成 × 装备加成 × 状态修正",
        "设计理念": "低境界差距小（新手阶段），大境界差距大（5-10倍，体现绝对压制）",
        "境界系数": {
            # 淬体期：肉身打磨，差距小
            "淬体一重": 10, "淬体二重": 15, "淬体三重": 20, "淬体四重": 28,
            "淬体五重": 38, "淬体六重": 50, "淬体七重": 65, "淬体八重": 85, "淬体九重": 110,
            # 炼气期：御气开始，差距加大
            "炼气初期": 150, "炼气中期": 200, "炼气后期": 270, "炼气圆满": 360,
            # 筑基期：质变，差距拉大
            "筑基初期": 500, "筑基中期": 700, "筑基后期": 1000, "筑基圆满": 1400,
            # 金丹期：恐怖差距
            "金丹初期": 2000, "金丹中期": 3000, "金丹后期": 4500, "金丹圆满": 6500,
            # 元婴期：传奇级别
            "元婴初期": 10000, "元婴中期": 15000, "元婴后期": 22000, "元婴圆满": 32000,
            # 化神期：神话级别
            "化神初期": 50000, "化神中期": 80000, "化神后期": 120000, "化神圆满": 180000,
            # 高境界：指数增长
            "炼虚": 300000, "合体": 600000, "大乘": 1500000, "渡劫": 5000000
        },
        "大境界差距": {
            "淬体→炼气": "约3-5倍（淬体九重110 vs 炼气初期150）",
            "炼气→筑基": "约3-4倍（炼气圆满360 vs 筑基初期500）",
            "筑基→金丹": "约2-3倍（筑基圆满1400 vs 金丹初期2000）",
            "金丹→元婴": "约2-3倍（金丹圆满6500 vs 元婴初期10000）",
            "元婴→化神": "约3-4倍（元婴圆满32000 vs 化神初期50000）",
            "化神→炼虚": "约2倍（化神圆满180000 vs 炼虚300000）",
            "炼虚→合体": "约2倍",
            "合体→大乘": "约2.5倍",
            "大乘→渡劫": "约3倍"
        },
        "战斗规则": {
            "同境界": "技巧/装备/经验决定，胜率40-60%",
            "差一小境界": "优势方胜率60-75%",
            "差一大境界": "优势方胜率85-95%（绝对压制）",
            "差两大境界": "优势方胜率>99%（近乎必死）",
            "越级挑战条件": "Legendary装备或天命剑激活或地利优势"
        }
    },
    "characters": {
        "char_萧辰_0001": {"realm": "淬体四重", "power": 28, "notes": "主角，天命剑封印中"},
        "char_苏逸_0001": {"realm": "炼气初期", "power": 150, "notes": "师兄"},
        "char_王大_0001": {"realm": "淬体四重", "power": 28, "notes": "前期反派，被萧辰击败"},
        "char_王执事_0001": {"realm": "炼气后期", "power": 270, "notes": "中层反派"},
        "char_风清扬_0002": {"realm": "筑基后期", "power": 1000, "notes": "剑阁阁主"},
        "char_李白白_0002": {"realm": "筑基圆满", "power": 1400, "notes": "天剑宗宗主，正道领袖"},
        "char_血煞老祖_0001": {"realm": "金丹初期", "power": 2000, "notes": "魔道巨头，一击毁城"},
        "char_血姬_0002": {"realm": "金丹后期", "power": 4500, "notes": "上古血族纯血"},
        "char_鲛人王_0001": {"realm": "金丹中期", "power": 3000, "notes": "东海霸主"},
        "char_逍遥子_0002": {"realm": "元婴初期", "power": 10000, "notes": "中立势力领袖，深不可测"}
    }
}

# 更新世界包
entries[POWER_SYSTEM["id"]] = POWER_SYSTEM

# 更新各角色武力值
for char_id, power_data in POWER_SYSTEM["characters"].items():
    if char_id in entries:
        entries[char_id]["power_value"] = power_data["power"]
        entries[char_id]["power_realm"] = power_data["realm"]
        entries[char_id]["power_notes"] = power_data["notes"]

# 保存
output = data.copy()
output["entries"] = entries
output["updated_at"] = datetime.now().isoformat()

with open(WORLD_DIR / "玄天大陆.json", 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print("✅ 武力值体系已修正！")
print("\n📊 境界武力值对照表（修正版）:")
print("-" * 50)
for realm, value in POWER_SYSTEM["system"]["境界系数"].items():
    print(f"  {realm:12s}: {value:>8d}")

print("\n👤 角色武力值:")
print("-" * 50)
for char_id, data in POWER_SYSTEM["characters"].items():
    print(f"  {char_id}: {data['power']:>6d} ({data['realm']}) - {data['notes']}")

print("\n📈 大境界差距验证:")
print("-" * 50)
print(f"  淬体九重({POWER_SYSTEM['system']['境界系数']['淬体九重']}) → 炼气初期({POWER_SYSTEM['system']['境界系数']['炼气初期']}) = {POWER_SYSTEM['system']['境界系数']['炼气初期']/POWER_SYSTEM['system']['境界系数']['淬体九重']:.1f}倍")
print(f"  炼气圆满({POWER_SYSTEM['system']['境界系数']['炼气圆满']}) → 筑基初期({POWER_SYSTEM['system']['境界系数']['筑基初期']}) = {POWER_SYSTEM['system']['境界系数']['筑基初期']/POWER_SYSTEM['system']['境界系数']['炼气圆满']:.1f}倍")
print(f"  筑基圆满({POWER_SYSTEM['system']['境界系数']['筑基圆满']}) → 金丹初期({POWER_SYSTEM['system']['境界系数']['金丹初期']}) = {POWER_SYSTEM['system']['境界系数']['金丹初期']/POWER_SYSTEM['system']['境界系数']['筑基圆满']:.1f}倍")
print(f"  金丹圆满({POWER_SYSTEM['system']['境界系数']['金丹圆满']}) → 元婴初期({POWER_SYSTEM['system']['境界系数']['元婴初期']}) = {POWER_SYSTEM['system']['境界系数']['元婴初期']/POWER_SYSTEM['system']['境界系数']['金丹圆满']:.1f}倍")
print(f"  元婴圆满({POWER_SYSTEM['system']['境界系数']['元婴圆满']}) → 化神初期({POWER_SYSTEM['system']['境界系数']['化神初期']}) = {POWER_SYSTEM['system']['境界系数']['化神初期']/POWER_SYSTEM['system']['境界系数']['元婴圆满']:.1f}倍")
