#!/usr/bin/env python3
"""
修正角色境界：宗主必须足够强
"""

import json
from pathlib import Path
from datetime import datetime

WORLD_DIR = Path("/var/minis/shared/novel-team/.world-packs")

data = json.loads((WORLD_DIR / "玄天大陆.json").read_text(encoding='utf-8'))
entries = data['entries']

# ============================================================
# 修正：宗主必须是正道最强，不能比魔道门主弱
# ============================================================

CORRECTIONS = {
    # 天剑宗宗主 - 正道领袖，必须最强
    "char_李白白_0002": {
        "name": "李白白",
        "old_realm": "筑基圆满",
        "new_realm": "金丹初期",
        "old_power": 1400,
        "new_power": 2000,
        "reason": "正道第一宗宗主，必须与魔道门主持平或更强"
    },
    # 剑阁阁主 - 应该比外门执事强得多
    "char_风清扬_0002": {
        "name": "风清扬",
        "old_realm": "筑基后期",
        "new_realm": "筑基圆满",
        "old_power": 1000,
        "new_power": 1400,
        "reason": "剑阁传承者，应该是内门最强"
    },
    # 王执事 - 中层反派，保持合理
    "char_王执事_0001": {
        "name": "王执事",
        "old_realm": "炼气后期",
        "new_realm": "炼气后期",
        "old_power": 270,
        "new_power": 270,
        "reason": "无变化，炼气后期合理"
    },
    # 逍遥子 - 中立领袖，保持元婴
    "char_逍遥子_0002": {
        "name": "逍遥子",
        "old_realm": "元婴初期",
        "new_realm": "元婴初期",
        "old_power": 10000,
        "new_power": 10000,
        "reason": "活了五百年，元婴合理"
    }
}

# 更新条目
for char_id, info in CORRECTIONS.items():
    if char_id in entries:
        old_realm = entries[char_id].get("fields", [])
        for field in old_realm:
            if field.get("name") == "境界":
                field["value"] = info["new_realm"]
        
        entries[char_id]["power_value"] = info["new_power"]
        entries[char_id]["power_realm"] = info["new_realm"]
        entries[char_id]["power_notes"] = info["reason"]
        
        print(f"✅ {info['name']}: {info['old_realm']}(武力{info['old_power']}) → {info['new_realm']}(武力{info['new_power']})")
        print(f"   原因：{info['reason']}")
        print()

# 保存
data["entries"] = entries
data["updated_at"] = datetime.now().isoformat()

with open(WORLD_DIR / "玄天大陆.json", 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("=" * 60)
print("📊 修正后角色武力值对照表:")
print("=" * 60)
print(f"{'角色':<12s} {'境界':<10s} {'武力值':>8s} {'定位'}")
print("-" * 60)
print(f"{'萧辰':<12s} {'淬体四重':<10s} {'28':>8d} {'主角'}")
print(f"{'苏逸':<12s} {'炼气初期':<10s} {'150':>8d} {'师兄'}")
print(f"{'王执事':<12s} {'炼气后期':<10s} {'270':>8d} {'中层反派'}")
print(f"{'风清扬':<12s} {'筑基圆满':<10s} {'1400':>8d} {'剑阁阁主'}")
print(f"{'李白白':<12s} {'金丹初期':<10s} {'2000':>8d} {'天剑宗宗主'}")
print(f"{'血煞老祖':<12s} {'金丹初期':<10s} {'2000':>8d} {'血煞门门主'}")
print(f"{'血姬':<12s} {'金丹后期':<10s} {'4500':>8d} {'血族纯血'}")
print(f"{'鲛人王':<12s} {'金丹中期':<10s} {'3000':>8d} {'东海霸主'}")
print(f"{'逍遥子':<12s} {'元婴初期':<10s} {'10000':>8d} {'中立领袖'}")

print("\n✅ 战力平衡验证:")
print(f"   天剑宗宗主(2000) = 血煞门门主(2000) → 正道魔道持平 ✅")
print(f"   逍遥子(10000) > 金丹级 → 中立势力足够威慑三方 ✅")
print(f"   萧辰(28) vs 王执事(270) → 越级挑战需天命剑 ✅")
