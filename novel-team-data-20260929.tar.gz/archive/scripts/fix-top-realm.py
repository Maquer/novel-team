#!/usr/bin/env python3
"""
修正顶级宗门宗主境界：应该是元婴级
"""

import json
from pathlib import Path
from datetime import datetime

WORLD_DIR = Path("/var/minis/shared/novel-team/.world-packs")

data = json.loads((WORLD_DIR / "玄天大陆.json").read_text(encoding='utf-8'))
entries = data['entries']

# ============================================================
# 修正：顶级宗主应该是元婴期
# ============================================================

CORRECTIONS = {
    # 天剑宗宗主 - 正道第一宗，应该是元婴初期
    "char_李白白_0002": {
        "old_realm": "金丹初期",
        "new_realm": "元婴初期",
        "old_power": 2000,
        "new_power": 10000,
        "reason": "正道第一宗宗主，应该与魔道门主持平或更强"
    },
    # 血煞门门主 - 魔道大宗，应该是元婴初期
    "char_血煞老祖_0001": {
        "old_realm": "金丹初期",
        "new_realm": "元婴初期",
        "old_power": 2000,
        "new_power": 10000,
        "reason": "魔道大宗门主，应该与正道宗主持平"
    },
    # 逍遥子 - 中立势力，已经是元婴初期，保持不变
    "char_逍遥子_0002": {
        "old_realm": "元婴初期",
        "new_realm": "元婴初期",
        "old_power": 10000,
        "new_power": 10000,
        "reason": "已经是元婴初期，无需调整"
    },
    # 青云宗宗主 - 正道第二宗，应该是筑基圆满或金丹初期
    "org_青云宗_0001": {
        "old_realm": "筑基后期",
        "new_realm": "筑基圆满",
        "old_power": 580,
        "new_power": 1400,
        "reason": "正道第二宗，宗主应该是筑基圆满"
    }
}

# 更新条目
for entry_id, info in CORRECTIONS.items():
    if entry_id in entries:
        # 更新字段
        for field in entries[entry_id].get("fields", []):
            if field.get("name") == "境界":
                field["value"] = info["new_realm"]
        
        # 更新武力值
        entries[entry_id]["power_value"] = info["new_power"]
        entries[entry_id]["power_notes"] = info["reason"]
        
        print(f"✅ {info['reason']}")
        print(f"   {entry_id}: {info['old_realm']}(武力{info['old_power']}) → {info['new_realm']}(武力{info['new_power']})")
        print()

# 保存
data["entries"] = entries
data["updated_at"] = datetime.now().isoformat()

with open(WORLD_DIR / "玄天大陆.json", 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("=" * 60)
print("📊 修正后境界分布:")
print("=" * 60)
print(f"{'角色':<12s} {'境界':<10s} {'武力值':>8s} {'定位'}")
print("-" * 60)
print(f"{'萧辰':<12s} {'淬体四重':<10s} {'28':>8d} {'主角'}")
print(f"{'苏逸':<12s} {'炼气初期':<10s} {'150':>8d} {'师兄'}")
print(f"{'王执事':<12s} {'炼气后期':<10s} {'270':>8d} {'中层反派'}")
print(f"{'风清扬':<12s} {'筑基圆满':<10s} {'1400':>8d} {'剑阁阁主'}")
print(f"{'李白白':<12s} {'元婴初期':<10s} {'10000':>8d} {'天剑宗宗主'}")
print(f"{'血煞老祖':<12s} {'元婴初期':<10s} {'10000':>8d} {'血煞门门主'}")
print(f"{'逍遥子':<12s} {'元婴初期':<10s} {'10000':>8d} {'逍遥阁阁主'}")
print()
print("✅ 战力平衡验证:")
print(f"   天剑宗宗主(10000) = 血煞门门主(10000) → 正道魔道持平 ✅")
print(f"   逍遥子(10000) = 宗主级别 → 三方平衡 ✅")
print(f"   萧辰(28) vs 所有境界 → 差距巨大，需成长 ✅")
