#!/usr/bin/env python3
"""
修正宗门领袖境界设定
"""

import json
from pathlib import Path

WORLD_DIR = Path("/var/minis/shared/novel-team/.world-packs")

data = json.loads((WORLD_DIR / "玄天大陆.json").read_text(encoding='utf-8'))
entries = data['entries']

# ============================================================
# 问题分析
# ============================================================

print("📊 当前境界分布:")
print("-" * 60)
print("第1境·淬体: 1-9重   (0-110武力值)   - 外门弟子")
print("第2境·炼气: 初-满   (150-360)       - 内门精英")
print("第3境·筑基: 初-满   (500-1400)      - 执事/长老")
print("第4境·金丹: 初-满   (2000-6500)     - 宗主/门主 ← 当前")
print("第5境·元婴: 初-满   (10000-32000)   - 逍遥子 ← 更高")
print("第6境·化神: 初-满   (50000-180000)  - 传说中的境界")
print("第7-10境    更高层次    - 飞升级别")
print()

# ============================================================
# 修正方案
# ============================================================

# 方案A：宗主应该是元婴初期（更高境界）
# 但这样会拉低血煞老祖的档次

# 方案B：保持金丹初期，但解释合理性
# 天剑宗宗主和血煞门主都是金丹初期，这是正常的
# 元婴级是传说级别，只有少数存在

# 当前设定其实合理，需要的是解释：
CORRECTIONS = {
    "power_境界平衡_0001": {
        "id": "power_境界平衡_0001",
        "kind": "secret",
        "name": "境界平衡说明",
        "status": "canon",
        "tagline": "为什么宗主只是金丹初期？因为元婴已是传说",
        "fields": [
            {"name": "核心原则", "value": "大境界差距1.4-1.7倍，同级别势力领袖应持平"},
            {"name": "金丹初期", "value": "正道/魔道大宗宗主级别，一击毁城"},
            {"name": "元婴初期", "value": "传说级别，活了500年以上的老怪物"},
            {"name": "为何逍遥子是元婴", "value": "活了500年，中立势力积累的底蕴"},
            {"name": "为何其他宗主不是元婴", "value": "天剑宗/血煞门刚复兴不久，还未出现元婴"},
            {"name": "未来趋势", "value": "萧辰成长后，可能成为新一代元婴"}
        ]
    },
    "char_李白白_0002": {
        "fields": [
            {"name": "身份", "value": "天剑宗宗主"},
            {"name": "境界", "value": "金丹初期"},
            {"name": "性格", "value": "沉稳睿智"},
            {"name": "外貌", "value": "白发白须，仙风道骨"},
            {"name": "背景", "value": "李太白后裔，守护天命剑秘密"},
            {"name": "目标", "value": "等待天命之人，重启封印"},
            {"name": "秘密", "value": "知道萧辰身世"},
            {"name": "战力说明", "value": "金丹初期是宗主正常水平，元婴已是传说"}
        ]
    },
    "char_逍遥子_0002": {
        "fields": [
            {"name": "身份", "value": "逍遥阁阁主"},
            {"name": "境界", "value": "元婴初期"},
            {"name": "性格", "value": "洒脱精明"},
            {"name": "外貌", "value": "中年模样，常带笑意，目光深邃"},
            {"name": "背景", "value": "活了五百年，见证过天裂之劫的部分真相"},
            {"name": "目标", "value": "维持三方平衡，避免大战"},
            {"name": "秘密", "value": "掌握《九转还魂丹》残卷"},
            {"name": "战力说明", "value": "元婴初期是稀有存在，活了500年的老怪物"}
        ]
    }
}

# 更新条目
for entry_id, entry_data in CORRECTIONS.items():
    if entry_id in entries:
        if "fields" in entry_data:
            entries[entry_id]["fields"] = entry_data["fields"]
        print(f"✅ 已更新: {entry_id}")

# 保存
data["entries"] = entries
data["updated_at"] = __import__('datetime').datetime.now().isoformat()

with open(WORLD_DIR / "玄天大陆.json", 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("\n" + "=" * 60)
print("📊 境界平衡说明:")
print("=" * 60)
print("""
【为什么宗主只是金丹初期？】

1. 金丹期 = 大宗宗主级别
   - 一击毁城，陆地神仙级别
   - 正道/魔道大宗宗主都是这个级别
   - 这是正常的，不是弱者

2. 元婴期 = 传说级别
   - 活了500年以上的老怪物
   - 整个玄天大陆只有1-2个
   - 逍遥子是因为活了500年才达到

3. 战力平衡
   - 天剑宗宗主(2000) = 血煞门门主(2000) ✅ 持平
   - 逍遥子(10000) 是例外，因为中立+长寿
   - 这不是bug，是设定
""")
