#!/usr/bin/env python3
"""
计算十个境界的合理数值比例 - 最终版
设计原则：
1. 小境界内：每重×1.3倍（渐进增长）
2. 大境界间：×4→×5→×6递增（体现绝对压制且递增）
3. 总跨度：合理范围
"""

print("=" * 70)
print("    十个境界数值比例设计（最终版）")
print("=" * 70)
print()

# 境界定义
REALMS = [
    ("淬体", ["一重", "二重", "三重", "四重", "五重", "六重", "七重", "八重", "九重"]),
    ("炼气", ["初期", "中期", "后期", "圆满"]),
    ("筑基", ["初期", "中期", "后期", "圆满"]),
    ("金丹", ["初期", "中期", "后期", "圆满"]),
    ("元婴", ["初期", "中期", "后期", "圆满"]),
    ("化神", ["初期", "中期", "后期", "圆满"]),
    ("炼虚", [""]),
    ("合体", [""]),
    ("大乘", [""]),
    ("渡劫", [""]),
]

# 设计方案：小境界×1.3，大境界递增×4→×5→×6
SMALL_RATIO = 1.3
BIG_RATIOS = [4, 5, 5, 6, 6, 7, 8, 10, 12]  # 9个大境界跃迁

base_value = 10
values = {}
current = base_value

for realm_idx, (realm_name, stages) in enumerate(REALMS):
    if realm_idx > 0:
        current = round(current * BIG_RATIOS[realm_idx - 1])
    
    for stage_idx, stage in enumerate(stages):
        if stage:
            key = f"{realm_name}{stage}"
        else:
            key = realm_name
        values[key] = current
        if stage_idx < len(stages) - 1:
            current = round(current * SMALL_RATIO)

print("【最终方案】小境界×1.3，大境界递增×4→×12")
print("-" * 70)
print(f"{'境界':<12s} {'武力值':>8s} {'说明'}")
print("-" * 70)

descriptions = {
    "淬体一重": "入门", "淬体四重": "主角初始", "淬体九重": "外门巅峰",
    "炼气初期": "内门门槛", "炼气圆满": "精英",
    "筑基初期": "正式弟子", "筑基圆满": "长老候选",
    "金丹初期": "宗主级别", "金丹圆满": "一流高手",
    "元婴初期": "传说级", "元婴圆满": "陆地神仙",
    "化神初期": "飞天遁地", "化神圆满": "半步飞升",
    "炼虚": "炼化虚空", "合体": "身心合一",
    "大乘": "半步仙人", "渡劫": "飞升仙界"
}

for realm_name, stages in REALMS:
    first_val = None
    last_val = None
    first_key = None
    for stage in stages:
        key = f"{realm_name}{stage}" if stage else realm_name
        val = values[key]
        if first_val is None:
            first_val = val
            first_key = key
        last_val = val
    
    desc = descriptions.get(first_key, "")
    display_name = f"{realm_name}{stages[-1] if stages else ''}"
    print(f"{display_name:<12s} {first_val:>6d} → {last_val:>6d}  {desc}")

print("-" * 70)
total_span = values['渡劫'] / values['淬体一重']
print(f"总跨度: {total_span:.0f}倍")
print()

print("【大境界倍数验证】")
print("-" * 70)
prev_last = None
for realm_name, stages in REALMS:
    last_key = f"{realm_name}{stages[-1]}" if stages else realm_name
    last_val = values[last_key]
    if prev_last is not None:
        ratio = last_val / prev_last
        print(f"  {prev_last:>8d} → {last_val:>8d} = ×{ratio:.1f}")
    prev_last = last_val

print()
print("【关键角色武力值】")
print("-" * 70)
key_characters = [
    ("萧辰", "淬体四重", values["淬体四重"]),
    ("王大", "淬体四重", values["淬体四重"]),
    ("苏逸", "炼气初期", values["炼气初期"]),
    ("王执事", "炼气后期", values["炼气后期"]),
    ("风清扬", "筑基圆满", values["筑基圆满"]),
    ("李白白", "金丹初期", values["金丹初期"]),
    ("血煞老祖", "金丹初期", values["金丹初期"]),
    ("鲛人王", "金丹中期", values["金丹中期"]),
    ("血姬", "金丹后期", values["金丹后期"]),
    ("逍遥子", "元婴初期", values["元婴初期"]),
]

for name, realm, power in key_characters:
    print(f"  {name:<10s} {realm:<10s} 武力值: {power:>7d}")

print()
print("【战力对比验证】")
print("-" * 70)
print(f"  萧辰({values['淬体四重']}) vs 王大({values['淬体四重']}) → 均势 ✅")
print(f"  萧辰({values['淬体四重']}) vs 王执事({values['炼气后期']}) → {values['炼气后期']/values['淬体四重']:.1f}倍差距，难以匹敌 ✅")
print(f"  萧辰({values['淬体四重']}) vs 风清扬({values['筑基圆满']}) → {values['筑基圆满']/values['淬体四重']:.0f}倍差距，绝对压制 ✅")
print(f"  李白白({values['金丹初期']}) vs 血煞老祖({values['金丹初期']}) → 持平，正道魔道对等 ✅")
print(f"  血煞老祖({values['金丹初期']}) vs 逍遥子({values['元婴初期']}) → {values['元婴初期']/values['金丹初期']:.1f}倍差距，中立势力威慑 ✅")
