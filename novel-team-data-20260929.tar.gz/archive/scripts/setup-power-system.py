#!/usr/bin/env python3
"""
建立《天命》武力值量化体系
"""

import json
from pathlib import Path
from datetime import datetime

WORLD_DIR = Path("/var/minis/shared/novel-team/.world-packs")

def load_world():
    f = WORLD_DIR / "玄天大陆.json"
    if f.exists():
        return json.loads(f.read_text(encoding='utf-8'))
    return None

data = load_world()
entries = data['entries'] if data else {}

# ============================================================
# 武力值量化体系
# ============================================================

POWER_SYSTEM = {
    "id": "power_武力量化_0001",
    "kind": "power",
    "name": "武力值量化体系",
    "status": "canon",
    "tagline": "标准化战力数值，所有角色/妖兽/装备可计算对比",
    "fields": [],
    "system": {
        "基础武力值公式": "武力值 = 境界系数 × 体质加成 × 功法加成 × 装备加成 × 状态修正",
        "境界系数": {
            "淬体一重": 10, "淬体二重": 15, "淬体三重": 20, "淬体四重": 28,
            "淬体五重": 38, "淬体六重": 50, "淬体七重": 65, "淬体八重": 85, "淬体九重": 110,
            "炼气初期": 150, "炼气中期": 180, "炼气后期": 220, "炼气圆满": 270,
            "筑基初期": 350, "筑基中期": 450, "筑基后期": 580, "筑基圆满": 750,
            "金丹初期": 1000, "金丹中期": 1300, "金丹后期": 1700, "金丹圆满": 2200,
            "元婴初期": 3000, "元婴中期": 4000, "元婴后期": 5500, "元婴圆满": 7500,
            "化神初期": 10000, "化神中期": 13000, "化神后期": 17000, "化神圆满": 22000,
            "炼虚": 30000, "合体": 50000, "大乘": 80000, "渡劫": 150000
        },
        "体质加成": {
            "普通": 1.0,
            "剑体": 1.3,
            "血体": 1.5,
            "丹体": 1.0,
            "上古血脉": 1.4
        },
        "功法加成": {
            "无": 1.0,
            "黄阶上品": 1.1,
            "玄阶上品": 1.25,
            "地阶上品": 1.5,
            "天阶中品": 1.8,
            "天阶上品": 2.2,
            "天阶极品": 2.8,
            "禁书": 3.5
        },
        "装备加成": {
            "无装备": 1.0,
            "凡器": 1.1,
            "灵器": 1.3,
            "法器": 1.5,
            "法宝": 2.0,
            "Legendary": 3.0
        },
        "状态修正": {
            "正常": 1.0,
            "轻伤": 0.9,
            "重伤": 0.7,
            "濒死": 0.5,
            "愤怒/拼命": 1.3,
            "天命剑激活": 2.0
        }
    },
    "战斗规则": {
        "胜率计算公式": "胜率 = 攻击方武力值 / (攻击方武力值 + 防守方武力值)",
        "越级挑战条件": "低境界需满足：武力值差≤30% 或 有Legendary装备或 有地利优势",
        "同境界胜负": "技巧+装备+经验决定，非绝对压制",
        "大境界差距": "相差一个完整大境界（如淬体vs炼气），胜率<5%（除非有 Legendary）"
    },
    "参考战力表": {
        "外门弟子平均": "淬体四重≈28武力值",
        "外门精英": "淬体六重≈50武力值",
        "内门弟子": "炼气初期≈150武力值",
        "外门执事": "炼气后期≈220武力值",
        "天剑宗宗主": "筑基圆满≈750武力值",
        "血煞老祖": "金丹初期≈1000武力值",
        "逍遥子": "元婴初期≈3000武力值"
    }
}

# 保存到世界包
entries[POWER_SYSTEM["id"]] = POWER_SYSTEM

# 更新各角色的武力值
CHARACTER_POWER = {
    "char_萧辰_0001": {"current": 28, "peak": 28, "notes": "淬体四重，天命剑封印中"},
    "char_苏逸_0001": {"current": 150, "peak": 150, "notes": "炼气初期"},
    "char_王大_0001": {"current": 28, "peak": 28, "notes": "淬体四重，被萧辰击败"},
    "char_王执事_0001": {"current": 220, "peak": 220, "notes": "炼气后期"},
    "char_李白白_0002": {"current": 750, "peak": 750, "notes": "筑基圆满，天剑宗宗主"},
    "char_血姬_0002": {"current": 2200, "peak": 2200, "notes": "金丹后期，血族纯血"},
    "char_风清扬_0002": {"current": 450, "peak": 450, "notes": "筑基后期，剑阁阁主"},
    "char_逍遥子_0002": {"current": 3000, "peak": 3000, "notes": "元婴初期，逍遥阁阁主"},
    "char_血煞老祖_0001": {"current": 1000, "peak": 1000, "notes": "金丹初期，血煞门门主"},
    "char_鲛人王_0001": {"current": 1300, "peak": 1300, "notes": "金丹中期，东海霸主"}
}

for char_id, power_data in CHARACTER_POWER.items():
    if char_id in entries:
        entries[char_id]["power_value"] = power_data["current"]
        entries[char_id]["power_peak"] = power_data["peak"]
        entries[char_id]["power_notes"] = power_data["notes"]

# 保存
output = data.copy()
output["entries"] = entries
output["updated_at"] = datetime.now().isoformat()

with open(WORLD_DIR / "玄天大陆.json", 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print("✅ 武力值量化体系已建立！")
print("\n📊 境界武力值对照表:")
for realm, value in POWER_SYSTEM["system"]["境界系数"].items():
    print(f"  {realm}: {value}")

print("\n👤 角色武力值:")
for char_id, data in CHARACTER_POWER.items():
    print(f"  {char_id}: {data['current']} ({data['notes']})")
