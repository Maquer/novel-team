#!/usr/bin/env python3
"""
创作门禁全流程检查器 — 强制集成 guard-v6 和 fact-ledger

用法：
  python quality-gate.py --chapter chapter-001.md --novel-id my-novel
  python quality-gate.py --chapter chapter-001.md --novel-id my-novel --commit
  python quality-gate.py --publish --chapter chapter-001.md --novel-id my-novel
"""

import json
import sys
import subprocess
from pathlib import Path
from datetime import datetime

BASE_DIR = Path("/var/minis/shared/novel-team")
PROJECTS_DIR = BASE_DIR / "projects"


def load_chapter(chapter_file: str) -> dict:
    """加载章节文件并解析元数据"""
    with open(chapter_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    metadata = {}
    body = content
    
    if content.startswith("---"):
        lines = content.split("\n")
        in_meta = False
        for line in lines[1:]:
            if line == "---":
                in_meta = False
                break
            if in_meta and ":" in line:
                key, value = line.split(":", 1)
                metadata[key.strip()] = value.strip()
            elif line.strip().startswith("-") or line.strip().startswith("*"):
                in_meta = True
        
        body_start = content.find("\n---\n") + 5
        body = content[body_start:].strip()
    
    return {"metadata": metadata, "body": body, "raw": content}


def run_gate_check(chapter_file: str, project_id: str) -> dict:
    """运行门禁检查"""
    try:
        result = subprocess.run(
            [sys.executable, str(BASE_DIR / "tools" / "gate-check.py"), 
             "check", "--file", chapter_file],
            capture_output=True,
            text=True,
            cwd=str(BASE_DIR)
        )
        return json.loads(result.stdout)
    except Exception as e:
        return {"error": str(e), "passed": False}


def run_guard_v6(novel_id: str) -> dict:
    """运行四道一致性防线校验"""
    # 构建 events.json, characters.json, entities.json 路径
    events_file = PROJECTS_DIR / novel_id / "events.json"
    characters_file = PROJECTS_DIR / novel_id / "characters" / "characters.json"
    entities_file = PROJECTS_DIR / novel_id / "world" / "entities.json"
    
    # 如果文件不存在，创建空文件
    for f in [events_file, characters_file, entities_file]:
        if not f.exists():
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(json.dumps([], ensure_ascii=False))
    
    try:
        result = subprocess.run(
            [sys.executable, str(BASE_DIR / "tools" / "guard-v6.py"),
             "check",
             "--events", str(events_file),
             "--characters", str(characters_file),
             "--entities", str(entities_file)],
            capture_output=True,
            text=True,
            cwd=str(BASE_DIR)
        )
        return {"returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    except Exception as e:
        return {"error": str(e)}


def update_fact_ledger(novel_id: str, chapter_data: dict) -> dict:
    """更新事实账本"""
    try:
        result = subprocess.run(
            [sys.executable, str(BASE_DIR / "tools" / "fact-ledger.py"),
             "add-fact",
             "--novel-id", novel_id,
             "--category", "chapter",
             "--content", chapter_data["body"][:100] + "..."],
            capture_output=True,
            text=True,
            cwd=str(BASE_DIR)
        )
        return {"returncode": result.returncode, "output": result.stdout}
    except Exception as e:
        return {"error": str(e)}


def commit_to_ledger(novel_id: str, chapter_num: int) -> bool:
    """将章节内容提交到事实账本（正文回流）"""
    ledger_dir = BASE_DIR / ".ledger" / novel_id
    ledger_dir.mkdir(parents=True, exist_ok=True)
    
    facts_file = ledger_dir / "facts.json"
    
    # 加载或创建事实库
    if facts_file.exists():
        facts = json.loads(facts_file.read_text(encoding='utf-8'))
    else:
        facts = {"facts": [], "timeline": [], "version": 1}
    
    # 添加新章节的事实
    facts["version"] += 1
    facts["facts"].append({
        "chapter": chapter_num,
        "timestamp": datetime.now().isoformat(),
        "status": "committed",
        "note": f"Chapter {chapter_num} committed to canon"
    })
    
    # 保存
    tmp = facts_file.with_suffix('.tmp')
    tmp.write_text(json.dumps(facts, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(facts_file)
    
    return True


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="小说创作全流程质量门禁")
    parser.add_argument("--chapter", required=True, help="章节文件路径")
    parser.add_argument("--novel-id", default="my-novel", help="小说项目ID")
    parser.add_argument("--commit", action="store_true", help="提交通过检查的章节到账本")
    parser.add_argument("--publish", action="store_true", help="发布确认（触发正文回流）")
    parser.add_argument("--chapter-num", type=int, default=1, help="章节编号")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("📖 小说创作质量门禁检查")
    print("=" * 60)
    
    # 步骤1: 加载章节
    print("\n[1/5] 加载章节...")
    chapter_data = load_chapter(args.chapter)
    print(f"  ✓ 已加载 {len(chapter_data['body'])} 字")
    
    # 步骤2: 门禁检查
    print("\n[2/5] 运行门禁检查 (gate-check)...")
    gate_result = run_gate_check(args.chapter, args.novel_id)
    
    if gate_result.get("error"):
        print(f"  ✗ 门禁检查失败: {gate_result['error']}")
        sys.exit(1)
    
    if not gate_result.get("passed", False):
        # 质量债务系统集成：所有门禁问题记录为债务，继续创作
        print(f"  ⚠️ 门禁发现问题，已记录为质量债务（不阻断创作流程）")

        # 尝试集成质量债务系统
        try:
            from pathlib import Path as P
            import sys as _sys
            _sys.path.insert(0, str(BASE_DIR / "tools"))
            from quality_debt import gate_result_to_debt

            # 从文件名提取章节号
            import re
            ch_match = re.search(r'chapter-(\d+)', args.chapter)
            chapter_num = int(ch_match.group(1)) if ch_match else args.chapter_num

            debt_result = gate_result_to_debt(gate_result, chapter_num, args.novel_id)
            print(f"  📝 新增 {debt_result.get('debts_added', 0)} 条质量债务")
            if debt_result.get('debt_ids'):
                print(f"  债务ID: {', '.join(debt_result['debt_ids'])}")
        except Exception as e:
            print(f"  ⚠️ 质量债务集成失败: {e}")

        # 记录门禁结果但不阻断
        print(f"  ✅ 继续创作流程（质量问题已记录，后续可修复）")

    else:
        print(f"  ✓ 门禁检查通过")
    
    # 步骤3: 四道防线校验
    print("\n[3/5] 运行一致性防线 (guard-v6)...")
    guard_result = run_guard_v6(args.novel_id)
    
    if guard_result.get("error"):
        print(f"  ⚠ guard-v6 检查跳过: {guard_result['error']}")
    else:
        if guard_result.get("returncode", 1) != 0:
            print(f"  ✗ 一致性校验失败!")
            print(guard_result.get("stderr", ""))
            sys.exit(1)
        print(f"  ✓ 一致性校验通过")
    
    # 步骤4: 更新事实账本
    print("\n[4/5] 更新事实账本 (fact-ledger)...")
    ledger_result = update_fact_ledger(args.novel_id, chapter_data)
    
    if ledger_result.get("error"):
        print(f"  ⚠ 账本更新跳过: {ledger_result['error']}")
    else:
        print(f"  ✓ 账本已更新")
    
    # 步骤5: 提交/发布确认
    if args.commit or args.publish:
        print("\n[5/5] 提交章节到正史...")
        if commit_to_ledger(args.novel_id, args.chapter_num):
            print(f"  ✓ 第 {args.chapter_num} 章已提交到正史")
            print(f"  ✓ 正文回流完成")
        else:
            print(f"  ✗ 提交失败")
            sys.exit(1)
    else:
        print("\n[5/5] 未提交 (使用 --commit 或 --publish 提交)")
    
    print("\n" + "=" * 60)
    print("✅ 质量门禁全流程通过!")
    print("=" * 60)


if __name__ == "__main__":
    main()
