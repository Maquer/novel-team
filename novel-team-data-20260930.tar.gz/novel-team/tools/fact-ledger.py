#!/usr/bin/env python3
"""
事实账本 + 认知分级系统 — 小说创作记忆系统

借鉴 StoryForge 四层记忆系统：
  正文 → 事实 → 摘要 → 检索

核心功能：
  1. 事实追踪：记录人物状态、物品归属、事件时间线
  2. 版本保护：正文变化使旧候选失效
  3. 摘要生成：章节/卷/全局三层摘要
  4. 检索索引：快速查找相关片段
  5. 认知分级：know/believe/suspect/infer 四层（借鉴 ai-novel-writer v6）

数据模型：
  - facts.json: 已确认事实账本
  - states.json: 人物/物品状态追踪
  - summaries.json: 三层摘要
  - index.json: 检索索引
  - knowledge.json: 认知分级系统
"""

import json
import os
import sys
import hashlib
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict
import argparse

# 代际项目守卫（唯一路径入口）
sys.path.insert(0, str(Path(__file__).parent))
from project_guard import resolve

# 数据目录（全局，不随代际变化）
LEDGER_DIR = Path("/var/minis/shared/novel-team/ledger")

# 认知分级类型
KNOW_TYPES = ["know", "believe", "suspect", "infer"]


class KnowledgeLedger:
    """认知分级系统（know/believe/suspect/infer）"""
    
    def __init__(self, novel_id: str):
        self.novel_id = novel_id
        self.db_path = resolve(novel_id).ledger() / "knowledge.json"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.data = self._load()
    
    def _load(self) -> Dict:
        raw = {}
        if self.db_path.exists():
            raw = json.loads(self.db_path.read_text(encoding='utf-8'))
        # 兼容归一化：老账本可能用 "facts"（列表）作认知存储，或缺失 knowledge/memories 键
        # 代码内部统一以 "knowledge" 键（列表）访问，这里做一次键映射，避免 KeyError
        if not isinstance(raw.get("knowledge"), list):
            raw["knowledge"] = raw.get("facts", [])
        if not isinstance(raw.get("memories"), list):
            raw["memories"] = []
        raw.setdefault("novel_id", self.novel_id)
        return raw
    
    def _save(self):
        tmp = self.db_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(self.db_path)
    
    def add_memory(self, content: str, memory_type: str = "chapter", 
                  chapter_id: str = "", metadata: Dict = None) -> str:
        """添加记忆到向量库（简化版）"""
        import time
        memory_id = f"M{len(self.data['memories'])+1:04d}"
        
        # 简化版：不实际调用ChromaDB，只记录元数据
        # 实际需要：
        # 1. 使用ONNX Embedding生成向量
        # 2. 存入ChromaDB collection
        
        memory = {
            "id": memory_id,
            "content": content,
            "type": memory_type,
            "chapter_id": chapter_id,
            "metadata": metadata or {},
            "created_at": time.time(),
            "embedding": None,  # 实际应存储向量
        }
        
        self.data["memories"].append(memory)
        self._save()
        
        return memory_id
    
    def retrieve_memories(self, query: str, top_k: int = 5, 
                         threshold: float = 0.7) -> List[Dict]:
        """语义检索记忆（简化版）"""
        # 简化版：返回最近的top_k条记忆
        # 实际需要：
        # 1. 使用Embedding模型生成查询向量
        # 2. 在ChromaDB中做相似度搜索
        # 3. 过滤低于threshold的结果
        
        memories = self.data.get("memories", [])
        
        # 按创建时间排序
        sorted_memories = sorted(
            memories,
            key=lambda m: m.get("created_at", 0),
            reverse=True
        )
        
        # 返回top_k
        return sorted_memories[:top_k]
    
    def add(self, character: str, know_type: str, content: str,
            source: str = "", confidence: float = 1.0) -> str:
        """添加认知记录"""
        if know_type not in KNOW_TYPES:
            raise ValueError(f"非法认知类型: {know_type}，可选: {KNOW_TYPES}")
        
        import time
        knowledge_id = f"K{len(self.data['knowledge'])+1:04d}"
        
        record = {
            "id": knowledge_id,
            "character": character,
            "type": know_type,
            "content": content,
            "source": source,
            "confidence": confidence,
            "created_at": time.time(),
        }
        
        self.data["knowledge"].append(record)
        self._save()
        
        return knowledge_id
    
    def get_all(self, character: str = None) -> List[Dict]:
        """获取所有认知（可过滤角色）"""
        if character:
            return [k for k in self.data["knowledge"] if k["character"] == character]
        return self.data["knowledge"]
    
    def check_conflict(self, character: str) -> List[Dict]:
        """检查认知冲突"""
        char_knowledge = self.get_all(character)
        
        know_facts = [k for k in char_knowledge if k["type"] == "know"]
        believe_facts = [k for k in char_knowledge if k["type"] == "believe"]
        
        conflicts = []
        for kf in know_facts:
            for bf in believe_facts:
                if kf["content"] != bf["content"] and len(kf["content"]) > 5:
                    conflicts.append({
                        "type": "conflict",
                        "know": kf["content"],
                        "believe": bf["content"],
                    })
        
        return conflicts


class FactLedger:
    """事实账本"""
    
    def __init__(self, novel_id: str):
        self.novel_id = novel_id
        self.facts_path = LEDGER_DIR / novel_id / "facts.json"
        self.states_path = LEDGER_DIR / novel_id / "states.json"
        self.facts_path.parent.mkdir(parents=True, exist_ok=True)
        self.facts = self._load_json(self.facts_path)
        self.states = self._load_json(self.states_path)
    
    def _load_json(self, path: Path) -> Dict:
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8'))
        return {}
    
    def _save_json(self, path: Path, data: Dict):
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(path)
    
    def add_fact(self, category: str, content: str, source: str = "") -> str:
        """添加事实"""
        import time
        fact_id = f"F{len(self.facts)+1:04d}"

        fact = {
            "id": fact_id,
            "category": category,
            "content": content,
            "source": source,
            "created_at": datetime.now().isoformat(),
            "verified": False,
        }

        self.facts[fact_id] = fact
        self._save_json(self.facts_path, self.facts)

        # 事件发射：新事实写入 → 触发世界包同步
        try:
            _events_dir = Path(__file__).parent.parent / ".events"
            _events_file = _events_dir / f"{self.novel_id}.jsonl"
            _events_dir.mkdir(parents=True, exist_ok=True)
            _evt = {"event": "FACT_ADDED",
                    "fact_id": fact_id,
                    "category": category,
                    "content": content[:200],
                    "timestamp": datetime.now().isoformat()}
            with open(_events_file, "a", encoding="utf-8") as _f:
                _f.write(json.dumps(_evt, ensure_ascii=False) + "\n")
        except Exception:
            pass  # 事件发射失败不阻塞主流程

        return fact_id
    
    def list_facts(self, category: str = None) -> List[Dict]:
        """列出事实"""
        if category:
            return [f for f in self.facts.values() if f["category"] == category]
        return list(self.facts.values())
    
    def update_state(self, entity: str, key: str, value: str):
        """更新状态"""
        if entity not in self.states:
            self.states[entity] = {}
        self.states[entity][key] = value
        self._save_json(self.states_path, self.states)
    
    def get_state(self, entity: str, key: str) -> Optional[str]:
        """获取状态"""
        return self.states.get(entity, {}).get(key)
    
    def add_account(self, entity: str, item: str, quantity: int, source: str = ""):
        """添加账目记录"""
        key = f"{entity}:{item}"
        if key not in self.states:
            self.states[key] = {"entity": entity, "item": item, "quantity": 0, "history": []}
        
        old_qty = self.states[key]["quantity"]
        new_qty = old_qty + quantity
        self.states[key]["quantity"] = new_qty
        self.states[key]["history"].append({
            "change": quantity,
            "old": old_qty,
            "new": new_qty,
            "source": source,
            "timestamp": datetime.now().isoformat(),
        })
        self._save_json(self.states_path, self.states)
    
    def check_account_jump(self, entity: str, item: str, allowed_jump_ratio: float = 0.5) -> Optional[str]:
        """
        检查账目跳变（防「上一章119发子弹、下一章12发」）
        
        Returns:
            None if OK, error message if jump detected
        """
        key = f"{entity}:{item}"
        if key not in self.states:
            return None
        
        state = self.states[key]
        history = state.get("history", [])
        
        if len(history) < 2:
            return None
        
        # 取最近两次记录
        last = history[-1]
        prev = history[-2]
        
        old_qty = prev["new"]
        new_qty = last["new"]
        
        if old_qty == 0:
            return None
        
        # 计算跳变比例
        jump_ratio = abs(new_qty - old_qty) / abs(old_qty)
        
        if jump_ratio > allowed_jump_ratio:
            return f"账目跳变检测: {entity}:{item} 从 {old_qty} 变为 {new_qty} (跳变{jump_ratio*100:.1f}%)"
        
        return None
    
    def report(self) -> Dict:
        """生成统计报告"""
        return {
            "novel_id": self.novel_id,
            "total_facts": len(self.facts),
            "total_entities": len(self.states),
            "facts_by_category": self._count_by_category(),
        }
    
    def _count_by_category(self) -> Dict:
        counts = {}
        for f in self.facts.values():
            cat = f["category"]
            counts[cat] = counts.get(cat, 0) + 1
        return counts


def main():
    parser = argparse.ArgumentParser(description="事实账本 + 认知分级系统")
    subparsers = parser.add_subparsers(dest="command")
    
    # fact命令
    p_fact = subparsers.add_parser("add-fact", help="添加事实")
    p_fact.add_argument("--novel-id", required=True)
    p_fact.add_argument("--category", required=True)
    p_fact.add_argument("--content", required=True)
    p_fact.add_argument("--source", default="")
    
    p_list = subparsers.add_parser("list-facts", help="列出事实")
    p_list.add_argument("--novel-id", required=True)
    p_list.add_argument("--category", default=None)
    
    p_state = subparsers.add_parser("update-state", help="更新状态")
    p_state.add_argument("--novel-id", required=True)
    p_state.add_argument("--entity", required=True)
    p_state.add_argument("--key", required=True)
    p_state.add_argument("--value", required=True)
    
    p_get = subparsers.add_parser("get-state", help="获取状态")
    p_get.add_argument("--novel-id", required=True)
    p_get.add_argument("--entity", required=True)
    p_get.add_argument("--key", required=True)
    
    p_summary = subparsers.add_parser("list-states", help="列出状态")
    p_summary.add_argument("--novel-id", required=True)
    
    p_report = subparsers.add_parser("report", help="统计报告")
    p_report.add_argument("--novel-id", required=True)
    
    # account命令
    p_acc = subparsers.add_parser("account", help="账目管理")
    p_acc.add_argument("--novel-id", required=True)
    p_acc.add_argument("action", choices=["add", "check", "list"])
    p_acc.add_argument("--entity", "-e", help="实体名")
    p_acc.add_argument("--item", "-i", help="物品名")
    p_acc.add_argument("--quantity", "-q", type=int, help="数量变化")
    p_acc.add_argument("--source", help="来源")
    
    # knowledge命令
    p_know = subparsers.add_parser("knowledge", help="认知分级系统")
    p_know.add_argument("--novel-id", required=True)
    p_know.add_argument("action", choices=["add", "list", "check", "summary"])
    p_know.add_argument("--character", "-c", help="角色名")
    p_know.add_argument("--type", "-t", choices=KNOW_TYPES, help="认知类型")
    p_know.add_argument("--content", help="认知内容")
    p_know.add_argument("--source", help="来源")
    
    args = parser.parse_args()
    
    if args.command in ["add-fact", "list-facts", "update-state", "get-state", "list-states", "report"]:
        ledger = FactLedger(args.novel_id)
        
        if args.command == "add-fact":
            fid = ledger.add_fact(args.category, args.content, args.source)
            print(f"✅ 已添事实: {fid}")
        
        elif args.command == "list-facts":
            facts = ledger.list_facts(args.category)
            print(f"\n📋 事实列表 (共{len(facts)}条):")
            for f in facts:
                print(f"  [{f['category']}] {f['content'][:50]}...")
        
        elif args.command == "update-state":
            ledger.update_state(args.entity, args.key, args.value)
            print(f"✅ 已更新状态: {args.entity}.{args.key} = {args.value}")
        
        elif args.command == "get-state":
            val = ledger.get_state(args.entity, args.key)
            print(f"{args.entity}.{args.key} = {val or '无'}")
        
        elif args.command == "list-states":
            print(f"\n📊 {args.novel_id} 的状态:")
            for entity, keys in ledger.states.items():
                print(f"  {entity}:")
                for k, v in keys.items():
                    print(f"    {k}: {v}")
        
        elif args.command == "report":
            report = ledger.report()
            print(f"\n📈 统计报告:")
            print(f"  事实总数: {report['total_facts']}")
            print(f"  实体数量: {report['total_entities']}")
            print(f"  分类分布: {json.dumps(report['facts_by_category'], ensure_ascii=False)}")
    
    elif args.command == "knowledge":
        knowledge_cmd(args)
    
    elif args.command == "account":
        account_cmd(args)
    
    else:
        parser.print_help()


def knowledge_cmd(args):
    """认知分级命令"""
    ledger = KnowledgeLedger(args.novel_id)
    
    if args.action == "add":
        if not args.character or not args.content:
            print("❌ 需要 --character 和 --content")
            return 1
        kid = ledger.add(args.character, args.type, args.content, args.source)
        print(f"✅ 已添加认知: {kid}")
        return 0
    
    elif args.action == "list":
        chars = ledger.get_all(args.character)
        print(f"\n📋 {'角色' + args.character if args.character else '全部'}的认知:")
        for k in chars:
            type_label = {"know": "确知", "believe": "相信", "suspect": "怀疑", "infer": "推断"}
            print(f"  [{type_label.get(k['type'], k['type'])}] {k['content'][:50]}...")
        return 0
    
    elif args.action == "check":
        conflicts = ledger.check_conflict(args.character)
        if conflicts:
            print(f"\n⚠️ 发现 {len(conflicts)} 个认知冲突:")
            for c in conflicts:
                print(f"  冲突: {c['know']} vs {c['believe']}")
        else:
            print("\n✅ 认知一致性检查通过")
        return 0
    
    elif args.action == "summary":
        total = len(ledger.data["knowledge"])
        by_type = {}
        for ktype in KNOW_TYPES:
            by_type[ktype] = len([k for k in ledger.data["knowledge"] if k["type"] == ktype])
        
        print(f"\n📊 认知统计:")
        print(f"  总计: {total}")
        for ktype, count in by_type.items():
            print(f"  {ktype}: {count}")
        return 0
    
    else:
        print("❌ 未知操作")
        return 1


if __name__ == "__main__":
    main()
