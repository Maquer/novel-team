#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
logic-review.py — 小说章节逻辑审查门禁
检查项：时代词汇/境界能力越界/神器感应/时间线矛盾/位置矛盾/门派设定冲突/句子重复/剑种连贯
"""
import json, re, sys, argparse
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parent.parent
RULES_PATH = ROOT / "config" / "logic-rules.json"
WORLD_PATH = ROOT / ".world-packs" / "玄天大陆.json"
CHARS_PATH = ROOT / "projects" / "my-novel" / "characters" / "characters.json"


def load_rules():
    return json.load(open(RULES_PATH, encoding="utf-8"))["rules"]


def load_world():
    try:
        return json.load(open(WORLD_PATH, encoding="utf-8"))
    except Exception:
        return {"entries": {}}


def load_chars():
    try:
        return json.load(open(CHARS_PATH, encoding="utf-8"))
    except Exception:
        return {"characters": []}


def strip_meta(content):
    """去掉 frontmatter 与 V/I/C/E 契约块，只留正文"""
    parts = content.split("---", 2)
    body = parts[2] if len(parts) >= 3 else content
    body = re.sub(r"^# .*\n", "", body)
    return body


def rule_era_words(text, cfg):
    issues = []
    for w in cfg["words"]:
        for m in re.finditer(re.escape(w), text):
            ctx = text[max(0, m.start()-15):m.end()+15].replace("\n", " ")
            issues.append({
                "rule": "时代词汇", "severity": cfg["severity"],
                "word": w, "context": f"...{ctx}..."
            })
    return issues


def detect_subject_realm(sentence, chars):
    """从句子中的角色名推断其境界"""
    for c in chars:
        if c["name"] in sentence:
            return c["name"], c.get("realm", "")
    return None, None


def rule_realm_capability(text, cfg, chars, world):
    """检测：淬体/炼气期不应具备筑基以上能力"""
    issues = []
    low = set(cfg["groups_low_forbidden"])
    # 按句子切
    for seg in re.split(r"[。！？\n]", text):
        if not seg.strip():
            continue
        name, realm = detect_subject_realm(seg, chars)
        if not realm:
            continue
        # 淬体期禁用：御剑飞行/神识/灵气外放/凌空/瞬移
        forbidden = low if "淬体" in realm or "炼气" in realm else set()
        for word in forbidden:
            if word in seg:
                issues.append({
                    "rule": "境界能力越界", "severity": cfg["severity"],
                    "detail": f"{name}（{realm}）出现超出境界的能力：『{word}』"
                })
    return issues


def rule_divine_sense(text, cfg, chars):
    """检测：非主角人物感应/察觉天命剑/神器"""
    issues = []
    triggers = cfg["trigger_words"]
    senses = cfg["sense_words"]
    # 按段切
    for para in re.split(r"\n{2,}", text):
        if not para.strip():
            continue
        has_trigger = any(t in para for t in triggers)
        if not has_trigger:
            continue
        # 段中出现的非主角人物 + 感知动词 = 违规
        for c in chars:
            if c.get("role") == "主角":
                continue
            if c["name"] in para and any(s in para for s in senses):
                issues.append({
                    "rule": "神器感应越界", "severity": cfg["severity"],
                    "detail": f"{c['name']}（{c.get('realm','')}）不应感应/察觉神器觉醒"
                })
    return issues


def rule_time_contradiction(text, cfg):
    issues = []
    starts = [(text.find(s), s) for s in cfg["start_signals"] if s in text]
    pendings = [(text.find(s), s) for s in cfg["pending_signals"] if s in text]
    if not starts or not pendings:
        return issues
    for sp, ss in starts:
        for pp, ps in pendings:
            if abs(sp - pp) <= cfg["window"]:
                issues.append({
                    "rule": "时间线矛盾", "severity": cfg["severity"],
                    "detail": f"『{ss}』与『{ps}』相距 {abs(sp-pp)} 字，可能矛盾"
                })
    return issues


def rule_position_contradiction(text, cfg):
    issues = []
    for pair in cfg["conflict_pairs"]:
        a, b = pair
        for ma in re.finditer(re.escape(a), text):
            for mb in re.finditer(re.escape(b), text):
                if abs(ma.start() - mb.start()) < 400:
                    issues.append({
                        "rule": "位置/行为逻辑矛盾", "severity": cfg["severity"],
                        "detail": f"『{a}』与共现：『{b}』"
                    })
    return issues


def rule_modern_item_org(text, cfg, world):
    issues = []
    # 找出章内出现的门派
    orgs = {v["name"]: v for v in world.get("entries", {}).values() if v.get("kind") == "org"}
    for org_name in orgs:
        if org_name not in text:
            continue
        forbidden = cfg["mappings"].get(org_name, [])
        for word in forbidden:
            if word in text:
                issues.append({
                    "rule": "门派设定冲突", "severity": cfg["severity"],
                    "detail": f"{org_name} 中出现『{word}』"
                })
    return issues


def rule_duplicate_sentences(text, min_len=8):
    issues = []
    sents = [s.strip() for s in re.split(r"[。！？\n]", text) if len(s.strip()) >= min_len]
    cnt = Counter(sents)
    for s, c in cnt.items():
        if c > 1:
            issues.append({
                "rule": "重复句子", "severity": "warn",
                "detail": f"『{s[:30]}』重复出现 {c} 次"
            })
    return issues


def rule_constitution_valid(text, cfg, world, chars):
    """检测：角色体质是否存在 + 体质能力是否越界"""
    issues = []
    const_ids = {k for k, v in world.get("entries", {}).items() if v.get("kind") == "constitution"}
    
    # 1. 引用有效性检查
    for c in chars:
        cid = c.get("constitution", "")
        if cid and cid not in const_ids:
            issues.append({
                "rule": "体质引用无效", "severity": "error",
                "detail": f"{c['name']}引用了不存在的体质: {cid}"
            })
    
    # 2. 体质能力越界检查
    for c in chars:
        cid = c.get("constitution", "")
        if cid not in const_ids:
            continue
        realm = c.get("realm", "")
        const_entry = world["entries"].get(cid, {})
        
        # 凡体/废体不应有超境界能力
        rarity = const_entry.get("rarity", "common")
        if rarity in ("low",) and "淬体" in realm:
            issues.append({
                "rule": "体质能力矛盾", "severity": "warn",
                "detail": f"{c['name']}(废体+{realm})不应有超凡表现"
            })
    
    return issues


def rule_constitution_sword_match(text, cfg, world, chars):
    """检测：只有天命体可感知天命剑"""
    issues = []
    legend_id = "constitution_legend_0001"
    legend_chars = [c["id"] for c in chars if c.get("constitution") == legend_id]
    legend_names = [c["name"] for c in chars if c.get("constitution") == legend_id]
    
    # 检查非天命体角色是否感知天命剑
    for para in re.split(r"\n{2,}", text):
        if "天命剑" not in para and "神器" not in para:
            continue
        for c in chars:
            if c["id"] in legend_chars:
                continue  # 跳过天命体
            if c["name"] in para:
                # 检查是否有感知动词
                sense_verbs = ["感应", "察觉", "听见", "听到", "看到", "发现", "感到", "神色", "脸色", "心里发毛"]
                if any(v in para for v in sense_verbs):
                    issues.append({
                        "rule": "体质能力越界", "severity": "error",
                        "detail": f"{c['name']}({c.get('constitution','')})不可感知天命剑"
                    })
    return issues


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"文件不存在: {path}")
        sys.exit(2)

    content = path.read_text(encoding="utf-8")
    text = strip_meta(content)
    rules = load_rules()
    chars = load_chars()["characters"]
    world = load_world()

    issues = []
    issues += rule_era_words(text, rules["era_words"])
    issues += rule_realm_capability(text, rules["realm_capability"], chars, world)
    issues += rule_divine_sense(text, rules["divine_sense_boundary"], chars)
    issues += rule_time_contradiction(text, rules["time_contradiction"])
    issues += rule_position_contradiction(text, rules["position_contradiction"])
    issues += rule_modern_item_org(text, rules["modern_item_org_conflict"], world)
    issues += rule_duplicate_sentences(text)
    issues += rule_constitution_valid(text, rules.get("constitution_valid", {}), world, chars)
    issues += rule_constitution_sword_match(text, rules.get("constitution_sword_match", {}), world, chars)

    errors = [i for i in issues if i.get("severity") == "error"]
    warns = [i for i in issues if i.get("severity") == "warn"]

    result = {"file": str(path), "status": "pass" if not errors else "fail",
              "errors": len(errors), "warnings": len(warns), "issues": issues}

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("=" * 60)
        print(f"🔍 逻辑审查: {path.name}")
        print("=" * 60)
        if not issues:
            print("  ✅ 无问题")
        for i in issues:
            tag = "❌" if i.get("severity") == "error" else "⚠️"
            print(f"  {tag} [{i['rule']}] {i.get('detail', i.get('word',''))}")
        print()
        print(f"状态: {'✅ PASS' if not errors else '❌ FAIL'} | 错误 {len(errors)} | 警告 {len(warns)}")

    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
