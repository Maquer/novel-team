#!/usr/bin/env python3
"""
质量债务管理器 — 借鉴 Biz Novel Studio 四档质量分类

核心原则：局部质量问题不阻断全局链。
只有 stop_for_replan 和不可恢复的数据完整性失败才能停止创作流程。

四档分类：
  local_patch_plan        — 本章小修可解决 → 继续下一章
  continue_with_warning   — 记录在案，暂不修复 → 继续下一章
  patchable_obligation_gap — 未来章节弥补 → 继续下一章
  defer_and_continue      — 低优先级，静默记录 → 继续下一章

两种阻断：
  stop_for_replan         — 需要重新规划（剧情方向问题）
  data_integrity_failure  — 数据账本损坏，无法继续
"""

import json
import sys
import argparse
from pathlib import Path
from datetime import datetime

BASE_DIR = Path("/var/minis/shared/novel-team")
DEBT_DIR = BASE_DIR / "ledger"

# 只有这两档阻断创作流程
BLOCKING_LEVELS = {"stop_for_replan", "data_integrity_failure"}

# 四档非阻断质量债务
DEBT_LEVELS = ["local_patch_plan", "continue_with_warning",
               "patchable_obligation_gap", "defer_and_continue"]

LEVEL_DESCRIPTIONS = {
    "local_patch_plan": "本章小修可解决，建议立即修复后继续",
    "continue_with_warning": "问题已记录，不修复即进入下一章",
    "patchable_obligation_gap": "未来章节弥补，当前不阻断",
    "defer_and_continue": "低优先级，静默记录",
    "stop_for_replan": "剧情方向需要重新规划，必须停止",
    "data_integrity_failure": "数据账本损坏，无法继续创作",
}


def debt_path(novel_id: str) -> Path:
    p = DEBT_DIR / novel_id
    p.mkdir(parents=True, exist_ok=True)
    return p / "quality-debt.json"


def load_debt(novel_id: str) -> dict:
    f = debt_path(novel_id)
    if f.exists():
        return json.loads(f.read_text(encoding="utf-8"))
    return {"chapter_debts": {}, "total_open": 0, "total_resolved": 0}


def save_debt(novel_id: str, data: dict):
    debt_path(novel_id).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def add_debt(novel_id: str, chapter: int, level: str,
             description: str, gate_name: str = "") -> dict:
    """添加一条质量债务，返回是否应阻断流程"""
    if level not in BLOCKING_LEVELS and level not in DEBT_LEVELS:
        raise ValueError(f"未知级别: {level}，可选: {DEBT_LEVELS + list(BLOCKING_LEVELS)}")

    data = load_debt(novel_id)
    key = str(chapter)
    if key not in data["chapter_debts"]:
        data["chapter_debts"][key] = []

    entry = {
        "id": f"QD-{chapter}-{len(data['chapter_debts'][key])+1:03d}",
        "chapter": chapter,
        "level": level,
        "gate_name": gate_name,
        "description": description,
        "status": "open",
        "created_at": datetime.now().isoformat(),
        "resolved_at": None,
    }
    data["chapter_debts"][key].append(entry)
    data["total_open"] = sum(
        1 for debts in data["chapter_debts"].values()
        for d in debts if d["status"] == "open")
    save_debt(novel_id, data)

    blocking = level in BLOCKING_LEVELS
    return {
        "entry": entry,
        "blocking": blocking,
        "continue_creation": not blocking,
        "suggestion": LEVEL_DESCRIPTIONS.get(level, ""),
    }


def resolve_debt(novel_id: str, debt_id: str, note: str = "") -> dict:
    data = load_debt(novel_id)
    for chapter_key, debts in data["chapter_debts"].items():
        for d in debts:
            if d["id"] == debt_id:
                d["status"] = "resolved"
                d["resolved_at"] = datetime.now().isoformat()
                d["resolve_note"] = note
                data["total_open"] = sum(
                    1 for ds in data["chapter_debts"].values()
                    for x in ds if x["status"] == "open")
                data["total_resolved"] = data.get("total_resolved", 0) + 1
                save_debt(novel_id, data)
                return {"ok": True, "debt": d}
    return {"ok": False, "error": f"未找到债务 {debt_id}"}


def list_debts(novel_id: str, chapter: int = None,
               status: str = "open") -> list:
    data = load_debt(novel_id)
    result = []
    chapters = [str(chapter)] if chapter else list(data["chapter_debts"].keys())
    for ck in chapters:
        for d in data["chapter_debts"].get(ck, []):
            if status == "all" or d["status"] == status:
                result.append(d)
    return sorted(result, key=lambda x: x["created_at"], reverse=True)


def gate_result_to_debt(gate_result: dict, chapter: int,
                        novel_id: str) -> dict:
    """
    将 gate-check.py 的结果转换为质量债务，返回是否可继续。

    映射规则（借鉴 Biz Novel Studio Quality Gate）：
      P0 fail (ai_tone, fact_consistency)  → local_patch_plan（继续）
      P0 fail (character_consistency)      → local_patch_plan（继续）
      P1 fail/warning                      → continue_with_warning
      P2 fail/warning                      → defer_and_continue
      数据账本损坏                          → data_integrity_failure（阻断）
      用户明确要求重新规划                   → stop_for_replan（阻断）
    """
    if gate_result.get("data_integrity_error"):
        add_debt(novel_id, chapter, "data_integrity_failure",
                 gate_result.get("error", "账本数据损坏"))
        return {"continue_creation": False, "reason": "data_integrity_failure"}

    debts_added = []
    p0_fails = gate_result.get("p0_failures", [])
    p1_warns = gate_result.get("p1_warnings", [])
    p2_sugs = gate_result.get("p2_suggestions", [])

    for f in p0_fails:
        r = add_debt(novel_id, chapter, "local_patch_plan", str(f))
        debts_added.append(r["entry"]["id"])

    for w in p1_warns:
        r = add_debt(novel_id, chapter, "continue_with_warning", str(w))
        debts_added.append(r["entry"]["id"])

    for s in p2_sugs:
        r = add_debt(novel_id, chapter, "defer_and_continue", str(s))
        debts_added.append(r["entry"]["id"])

    blocking = any(
        LEVEL_DESCRIPTIONS.get(
            next((d["level"] for d in
                  load_debt(novel_id)["chapter_debts"].get(str(chapter), [])
                  if d["id"] == did), ""), "") in BLOCKING_LEVELS
        for did in debts_added
    ) if debts_added else False

    return {
        "continue_creation": True,   # 四档质量债务不阻断
        "blocking": False,
        "debts_added": len(debts_added),
        "debt_ids": debts_added,
        "summary": f"第{chapter}章新增 {len(debts_added)} 条质量债务，创作流程继续",
    }


def main():
    parser = argparse.ArgumentParser(description="质量债务管理器")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_add = sub.add_parser("add", help="添加质量债务")
    p_add.add_argument("--novel-id", required=True)
    p_add.add_argument("--chapter", type=int, required=True)
    p_add.add_argument("--level", required=True,
                       choices=DEBT_LEVELS + list(BLOCKING_LEVELS))
    p_add.add_argument("--desc", required=True)
    p_add.add_argument("--gate", default="")

    p_list = sub.add_parser("list", help="列出质量债务")
    p_list.add_argument("--novel-id", required=True)
    p_list.add_argument("--chapter", type=int)
    p_list.add_argument("--status", default="open",
                        choices=["open", "resolved", "all"])

    p_res = sub.add_parser("resolve", help="标记债务已修复")
    p_res.add_argument("--novel-id", required=True)
    p_res.add_argument("--debt-id", required=True)
    p_res.add_argument("--note", default="")

    p_stats = sub.add_parser("stats", help="质量债务统计")
    p_stats.add_argument("--novel-id", required=True)

    args = parser.parse_args()

    if args.cmd == "add":
        r = add_debt(args.novel_id, args.chapter, args.level, args.desc, args.gate)
        icon = "🛑" if r["blocking"] else "✅"
        print(f"{icon} 债务已记录: {r['entry']['id']}")
        print(f"   级别: {args.level} — {r['suggestion']}")
        print(f"   继续创作: {'是' if r['continue_creation'] else '否（需人工介入）'}")

    elif args.cmd == "list":
        debts = list_debts(args.novel_id, args.chapter, args.status)
        if not debts:
            print("✅ 无质量债务")
            return
        print(f"共 {len(debts)} 条：")
        for d in debts:
            icon = {"local_patch_plan": "🔧", "continue_with_warning": "⚠️",
                    "patchable_obligation_gap": "📌", "defer_and_continue": "💤",
                    "stop_for_replan": "🛑", "data_integrity_failure": "💥"
                    }.get(d["level"], "•")
            print(f"  {icon} [{d['id']}] ch{d['chapter']} {d['level']}")
            print(f"     {d['description'][:80]}")

    elif args.cmd == "resolve":
        r = resolve_debt(args.novel_id, args.debt_id, args.note)
        if r["ok"]:
            print(f"✅ {args.debt_id} 已标记为已修复")
        else:
            print(f"❌ {r['error']}")

    elif args.cmd == "stats":
        data = load_debt(args.novel_id)
        print(f"质量债务统计 — {args.novel_id}")
        print(f"  未解决: {data['total_open']}")
        print(f"  已解决: {data.get('total_resolved', 0)}")
        by_level = {}
        for debts in data["chapter_debts"].values():
            for d in debts:
                if d["status"] == "open":
                    by_level[d["level"]] = by_level.get(d["level"], 0) + 1
        if by_level:
            print("  按级别：")
            for lvl, cnt in sorted(by_level.items()):
                print(f"    {lvl}: {cnt}")


if __name__ == "__main__":
    main()
