#!/usr/bin/env python3
"""
章节字数检查脚本 — 借鉴 chinese-novelist-skill

核心功能：
  1. 统计中文字数（排除标点符号和Markdown标记）
  2. 检查章节是否达标
  3. 生成检查报告
  4. 支持批量检查

使用：
  python wordcount-check.py chapter.md
  python wordcount-check.py --all ./chapters/
  python wordcount-check.py --all ./chapters/ --min-words 3500
"""

import sys
import re
from pathlib import Path
from typing import Dict, List
from datetime import datetime


def count_chinese_words(text: str) -> int:
    """统计中文字数（排除标点符号和Markdown标记）"""
    # 移除Markdown标记
    text = re.sub(r'#{1,6}\s*', '', text)  # 标题
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # 粗体
    text = re.sub(r'\*(.*?)\*', r'\1', text)  # 斜体
    text = re.sub(r'~~(.*?)~~', r'\1', text)  # 删除线
    text = re.sub(r'`(.*?)`', r'\1', text)  # 行内代码
    text = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', text)  # 链接
    text = re.sub(r'\[([^\]]*)\]\([^)]+\)', r'\1', text)  # 另一种链接格式

    # 统计中文字符（汉字）
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
    return len(chinese_chars)


def extract_content_from_chapter(file_path: Path) -> str:
    """从章节文件中提取正文内容（排除标题等元数据）"""
    try:
        content = file_path.read_text(encoding='utf-8')
    except Exception as e:
        return f"读取失败: {e}"

    # 查找正文开始位置（通常是第一个一级标题或二级标题之后）
    lines = content.split('\n')

    # 跳过开头的元数据（如 # 第XX章 标题）
    content_start = 0
    for i, line in enumerate(lines):
        if line.startswith('#') and '章' in line:
            content_start = i + 1
            break

    # 提取正文
    main_content = '\n'.join(lines[content_start:])
    return main_content


def check_chapter(file_path: Path, min_words: int = 3000) -> Dict:
    """检查单个章节的字数"""
    if not file_path.exists():
        return {
            'file': str(file_path),
            'exists': False,
            'word_count': 0,
            'status': 'error',
            'message': f'文件不存在: {file_path}'
        }

    main_content = extract_content_from_chapter(file_path)
    word_count = count_chinese_words(main_content)

    # v0.46.0新增：预测性分析
    prediction = predict_completion_rate(file_path.parent, min_words)

    status = 'pass' if word_count >= min_words else 'fail'
    message = f'字数: {word_count}' + (
        f' (✓ 达标)' if word_count >= min_words else f' (✗ 不足，需要至少 {min_words} 字)'
    )

    return {
        'file': str(file_path),
        'exists': True,
        'word_count': word_count,
        'min_words': min_words,
        'status': status,
        'message': message,
        'prediction': prediction
    }


def predict_completion_rate(chapters_dir: Path, min_words: int, days_ahead: int = 7) -> Dict:
    """
    预测性分析：基于当前进度预测能否按时完成（v0.46.0新增）

    参数：
        chapters_dir: 章节目录
        min_words: 目标字数
        days_ahead: 预测天数

    返回：
        预测结果字典
    """
    # 统计已完成章节
    chapter_files = list(chapters_dir.glob("*.md"))
    if not chapter_files:
        return {
            "status": "no_data",
            "message": "暂无章节数据，无法预测"
        }
    
    # 计算日均产量
    total_words = 0
    for f in chapter_files:
        content = extract_content_from_chapter(f)
        total_words += count_chinese_words(content)
    
    # 假设每天创作1章（可根据实际调整）
    daily_output = total_words / len(chapter_files) if chapter_files else 0
    target_daily = min_words
    
    # 预测状态
    if daily_output >= target_daily:
        prediction_status = "on_track"
        message = f"当前日均产量{daily_output:.0f}字，达标（目标{target_daily}字）"
    elif daily_output >= target_daily * 0.8:
        prediction_status = "at_risk"
        message = f"当前日均产量{daily_output:.0f}字，略低于目标（目标{target_daily}字），存在延期风险"
    else:
        prediction_status = "behind"
        message = f"当前日均产量{daily_output:.0f}字，远低于目标（目标{target_daily}字），预计延期"
    
    # 计算预计完成天数
    if daily_output > 0:
        estimated_days = int(min_words / daily_output)
    else:
        estimated_days = 999
    
    return {
        "status": prediction_status,
        "message": message,
        "daily_output": round(daily_output, 2),
        "target_daily": target_daily,
        "estimated_days_per_chapter": estimated_days,
        "days_ahead": days_ahead,
        "projected_total": int(daily_output * days_ahead)
    }

    return {
        'file': str(file_path),
        'exists': True,
        'word_count': word_count,
        'status': status,
        'message': message,
    }


def check_all_chapters(directory: Path, pattern: str = '第*.md', min_words: int = 3000) -> List[Dict]:
    """检查目录下所有符合模式的章节文件"""
    if not directory.exists():
        print(f'错误: 目录不存在 - {directory}')
        return []

    chapter_files = sorted(directory.glob(pattern))
    results = []

    for chapter_file in chapter_files:
        result = check_chapter(chapter_file, min_words)
        results.append(result)

    return results


def print_results(results: List[Dict], min_words: int = 3000):
    """打印检查结果"""
    if not results:
        print('没有找到章节文件')
        return

    total_words = 0
    passed = 0
    failed = 0

    print('\n' + '=' * 60)
    print('章节字数检查报告')
    print('=' * 60)

    for result in results:
        if not result['exists']:
            print(f'\n❌ {result["file"]}')
            print(f'   {result["message"]}')
            continue

        total_words += result['word_count']
        if result['status'] == 'pass':
            passed += 1
            icon = '✅'
        else:
            failed += 1
            icon = '⚠️ '

        print(f'\n{icon} {Path(result["file"]).name}')
        print(f'   {result["message"]}')

    print('\n' + '-' * 60)
    print(f'总计: {len(results)} 章 | {passed} 章达标 | {failed} 章不足 | 总字数: {total_words:,}')
    print('-' * 60)

    if failed > 0:
        print(f'\n⚠️  有 {failed} 章内容不足 {min_words} 字，建议使用扩充技巧:')
        print('   - 添加细节描写（环境、心理、动作）')
        print('   - 增加对话场景')
        print('   - 扩展人物内心活动')
        print('   - 补充背景故事')


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='章节字数检查工具（借鉴chinese-novelist-skill）')
    parser.add_argument('target', help='章节文件或目录路径')
    parser.add_argument('--min-words', '-m', type=int, default=3000, help='最小字数要求（默认3000）')
    parser.add_argument('--pattern', '-p', default='第*.md', help='文件匹配模式（默认第*.md）')
    parser.add_argument('--json', '-j', action='store_true', help='以JSON格式输出')
    
    args = parser.parse_args()
    
    target_path = Path(args.target)
    
    if target_path.is_file():
        # 单文件检查
        result = check_chapter(target_path, args.min_words)
        results = [result]
    elif target_path.is_dir():
        # 批量检查
        results = check_all_chapters(target_path, args.pattern, args.min_words)
    else:
        print(f'错误: 路径不存在 - {args.target}')
        return 1
    
    if args.json:
        import json
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print_results(results, args.min_words)
    
    return 0 if all(r['status'] == 'pass' for r in results if r['exists']) else 1


if __name__ == '__main__':
    sys.exit(main())
