#!/usr/bin/env python3
"""
门禁检查系统 — 六道门禁校验框架（v1.2，增加修改模式 + 状态降级）

功能：
  1. 协议解析检查
  2. 引用校验
  3. 一致性检查
  4. 未知实体检查
  5. 描写一致性检查
  6. 蓝图出场检查

设计原则：
  - 刚性门禁：核心规则不可突破（事实冲突、AI味超标）
  - 柔性门禁：允许一定偏差，但记录在案（字数偏差±10%）
  - 可解释性：每个检查项都有明确的标准和反馈

v1.2 新增：
  - 修改模式（--mode modify）：小改动跳过完整流程
  - 状态降级：final → polishing，记录修改历史
  - 字数变化阈值：>500字必须同步，<500字可选跳过
  - 修改记录文件：.novel/tracking/修改记录.md
"""

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# 代际项目守卫（唯一路径入口）
sys.path.insert(0, str(Path(__file__).parent))
from project_guard import resolve


# 门禁配置
GATE_CONFIG = {
    "word_count": {
        "enabled": True,
        "min_words": 2500,  # 目标字数（长篇标准：网文单章 2000-3000）
        "soft_min": 1500,   # 真正下限：低于此才 P1 警告（防短篇陷阱）
        "max_words": 5000,  # 高潮章上限
        "flexible_range": 0.10,  # 允许±10%偏差
        "critical": True  # 09-29 升级：低于 soft_min 必须记账（不是建议）
    },
    "cliche": {
        "enabled": True,
        "max_hits": 0,   # 命中即 P2 提示（不阻断），AI 腔/套路金句黑名单见 _check_cliche
        "critical": False
    },
    "ai_tone": {
        "enabled": True,
        "max_score": 15,
        "flexible_range": 0.05,  # 允许≤5分偏差
        "critical": True
    },
    "fact_consistency": {
        "enabled": True,
        "tolerance": "strict",  # 严格模式
        "critical": True
    },
    "forbidden_words": {
        "enabled": True,
        "max_count": 0,
        "critical": True
    },
    "metadata": {
        "enabled": True,
        "required_fields": ["title", "author", "date", "word_count"],
        "critical": True
    },
    "protocol": {
        "enabled": True,
        "critical": True
    },
    "blueprint": {
        "enabled": True,
        "critical": True
    }
}

# 修改模式下的跳过检查项（不跑，直接标记为 pass）
MODIFY_SKIP_GATES = [
    "ai_tone",       # 修改模式不跑完整质检
    "word_count",        # 小改动可跳过字数检查
    "forbidden_words",   # 修改模式不重复扫禁用词
    "hook",              # 钩子检查非必需
]

# 必须执行的检查项（无论什么模式）
MODIFY_REQUIRED_GATES = [
    "fact_consistency",  # 事实一致性不可跳过
    "protocol",          # 协议完整性
    "blueprint",         # 蓝图出场
    "logic_review",      # 逻辑审查
]


# 套路/AI腔黑名单（09-29 多模型测试新增）：拦『一眼假』的主要来源。
# 依据：字数门禁已软化，但"金句/套路结尾/陈旧比喻"此前无人检测——这正是
# 写作者说"一眼假、没有故事性"的根因。命中即 P2 提示（不阻断），允许少量误报。
CLICHE_PATTERNS = [
    (re.compile(r"故事.{0,4}才刚.{0,4}开始"), "套路结尾『故事才刚刚开始』"),
    (re.compile(r"才刚刚开始"), "套路『才刚刚开始』"),
    (re.compile(r"他知道.{0,6}(这不是|不是暂时的|是倒计时)"), "直白金句『他知道…是倒计时』"),
    (re.compile(r"他明白了[。．]"), "直白『他明白了』"),
    (re.compile(r"眼中闪过一丝"), "套路『眼中闪过一丝』"),
    (re.compile(r"湿透的黑布"), "陈旧比喻『湿透的黑布』"),
    (re.compile(r"沉甸甸地压"), "套路『沉甸甸地压』"),
    (re.compile(r"他的故事"), "套路『他的故事』"),
    (re.compile(r"(?:我要[^。；\n]{1,15}。){3,}"), "排比三连『我要…我要…我要…』"),
    (re.compile(r"(?m)^\s*最后[，,]"), "议论文总结腔『最后，…』（序数用法如『最后一口』不受影响）"),
]
# 日历报数阈值：一章内出现「第X天/周/夜/日」超过 N 处 → 疑似流水账（09-29 洞察：好故事靠事件驱动，不靠日历报数）
TIME_REPORT_THRESHOLD = 2
TIME_REPORT_RE = re.compile(r"第[一二三四五六七八九十0-9]{1,3}(天|周|夜|日)")


class GateChecker:
    def __init__(self, project_id: str):
        self.project_id = project_id
        self.project_dir = resolve(project_id).root_dir
        self.check_results = []
        # 状态机目录：存储审核状态
        # BUG 10 修复：修前在 __init__ 里 mkdir → 构造函数有文件系统副作用，
        # 仅实例化即把已删除的项目目录"复活"（跑一次门禁就重建 projects/<id>/.novel/）
        self.status_dir = self.project_dir / ".novel/tracking"
        # 门禁分级配置：P0阻断/P1警告/P2建议
        # 修前含 "character_consistency"：无任何实现函数，永远无法触发（phantom gate）
        self.p0_gates = ["ai_tone", "fact_consistency"]
        # protocol fail = 元数据缺失，同样不可 workaround → 计入 P0
        self.p0_gates += ["protocol"]
        # BUG 1 修复依据：这些 gate 的 status=="fail" 即触发硬阻断
        # （team-rules「阻断是异常姿态，只有不可 workaround 的问题才阻断」）
        self.BLOCK_GATES = ["fact_consistency", "ai_tone", "protocol"]
        self.p1_gates = ["word_count", "forbidden_words", "hook"]
        self.p2_gates = ["protocol", "blueprint", "consistency", "reference", "unknown_entities", "description_consistency", "cliche"]
    
    def check(self, chapter_file: str, flexible: bool = False, 
              mode: str = "write") -> Dict:
        """
        执行门禁检查

        参数：
            chapter_file: 章节文件路径
            flexible: 是否启用柔性模式
            mode: "write"（完整流程）或 "modify"（修改模式）

        返回：
            检查结果字典，包含分级统计
        """
        results = {
            "chapter_file": chapter_file,
            "flexible_mode": flexible,
            "mode": mode,
            "checks": {},
            "passed": True,
            "warnings": [],
            "errors": [],
            "p0_failures": [],  # P0阻断级
            "p1_warnings": [],  # P1警告级
            "p2_suggestions": [],  # P2建议级
            "summary": {},  # 汇总统计
        }

        if mode == "modify":
            return self._check_modify(chapter_file, results)
        
        # 默认完整流程
        content, metadata = self._load_chapter(chapter_file)
        if not content:
            results["passed"] = False
            results["errors"].append("无法读取章节文件")
            return results
        
        # 1. 协议解析检查
        results["checks"]["protocol"] = self._check_protocol(content, metadata)
        
        # 2. 引用校验
        results["checks"]["reference"] = self._check_references(content)
        
        # 3. 字数检查（BUG 3：修前嵌在 _check_consistency 内以 "consistency" 上报，
        #    而 p1_gates 引用的是 "word_count" → _classify_gate 落到默认 P2，
        #    且 _collect_errors 无 p2 桶 → 字数失败既不算入 summary 也不进修复顺序）
        results["checks"]["word_count"] = self._check_word_count(content)
        
        # 4. 禁用词检查（BUG 4/D2e：修前嵌在 _check_unknown_entities 内，
        #    该 gate 不在 p1_gates → 落 P2，与文档声明 P1 矛盾）
        results["checks"]["forbidden_words"] = self._check_forbidden_words(content)

        # 4b. 事实一致性（BUG 6：修前 p0_gates 声明了 fact_consistency 但无任何
        #     实现函数，事实冲突阻断条件永远无法触发）
        results["checks"]["fact_consistency"] = self._check_fact_consistency(content, chapter_file)
        
        # 5. 描写一致性检查
        results["checks"]["description_consistency"] = self._check_description_consistency(content)
        
        # 6. 蓝图出场检查
        results["checks"]["blueprint"] = self._check_blueprint(content, metadata)
        
        # 7. AI味检查（调用 novel-humanizer.py）
        results["checks"]["ai_tone"] = self._check_ai_tone(chapter_file)

        # 8. 章末钩子检查
        results["checks"]["hook"] = self._check_hook(content)

        # 9. 逻辑审查检查
        results["checks"]["logic_review"] = self._check_logic_review(chapter_file)

        # 10. 暗线追踪检查
        results["checks"]["darkthread"] = self._check_darkthread(chapter_file)
        results["checks"]["cliche"] = self._check_cliche(content)

        # 判定结果
        results["passed"] = self._evaluate_results(results["checks"], flexible)
        results["warnings"] = self._collect_warnings(results["checks"])
        results["errors"] = self._collect_errors(results["checks"])
        
        # 生成汇总统计
        # BUG 8 修复：P1/P2 gate 的 status=="fail" 归入 errors.p1/p2，
        # 而 summary 原先只读 warnings.p1/p2（仅收 status=="warning"）→ P1 失败被漏计。
        # 现两级桶都计入，与 generate_fix_order 的读取口径一致。
        _e, _w = results["errors"], results["warnings"]
        _p1 = len(_e.get("p1", [])) + len(_w.get("p1", []))
        _p2 = len(_e.get("p2", [])) + len(_w.get("p2", []))
        results["summary"] = {
            "p0_blockers": len(_e.get("p0", [])),
            "p1_warnings": _p1,
            "p2_suggestions": _p2,
            "total_issues": len(_e.get("p0", [])) + _p1 + _p2,
        }
        
        # BUG 7 配套：把阻断评估结果合并进返回体（此前算完就丢）
        if getattr(self, "last_evaluation", None):
            results["evaluation"] = self.last_evaluation

        # 保存结果
        self._save_result(results)
        
        return results

    def _check_modify(self, chapter_file: str, results: Dict) -> Dict:
        """
        修改模式：最小化检查，只跑必要门禁
        
        规则：
        - 事实一致性 ✅ 必须
        - 协议完整性 ✅ 必须
        - 蓝图出场 ✅ 必须
        - AI味检测 ❌ 跳过
        - 字数检查 ❌ 小改动跳过
        - 钩子检查 ❌ 跳过
        """
        content, metadata = self._load_chapter(chapter_file)
        if not content:
            results["passed"] = False
            results["errors"].append("无法读取章节文件")
            return results

        # 1. 事实一致性（必须）
        results["checks"]["fact_consistency"] = self._check_fact_consistency(content, chapter_file)

        # 2. 协议完整性（必须）
        results["checks"]["protocol"] = self._check_protocol(content, metadata)

        # 3. 蓝图出场（必须）
        results["checks"]["blueprint"] = self._check_blueprint(content, metadata)

        # 4. 其他检查项标记为跳过
        for gate in MODIFY_SKIP_GATES:
            results["checks"][gate] = {
                "status": "skipped",
                "reason": f"修改模式下跳过：{gate}",
                "details": []
            }

        # 判定
        results["passed"] = self._evaluate_results(results["checks"], flexible=False)
        results["warnings"] = self._collect_warnings(results["checks"])
        results["errors"] = self._collect_errors(results["checks"])
        
        results["summary"] = {
            "mode": "modify",
            "p0_blockers": len(results["errors"].get("p0", [])),
            "p1_warnings": len(results["errors"].get("p1", [])) + len(results["warnings"].get("p1", [])),
            "p2_suggestions": len(results["errors"].get("p2", [])) + len(results["warnings"].get("p2", [])),
            "skipped_gates": MODIFY_SKIP_GATES,
            "total_issues": sum([
                len(results["errors"].get("p0", [])),
                len(results["errors"].get("p1", [])) + len(results["warnings"].get("p1", [])),
                len(results["errors"].get("p2", [])) + len(results["warnings"].get("p2", [])),
            ]),
        }

        self._save_result(results)
        return results

    def _check_protocol(self, content: str, metadata: Dict) -> Dict:
        """1. 协议解析检查"""
        result = {"status": "pass", "details": []}
        
        # 检查元数据完整性
        for field in GATE_CONFIG["metadata"]["required_fields"]:
            if field not in metadata:
                result["status"] = "fail"
                result["details"].append(f"缺少元数据字段：{field}")
        
        return result
    
    def _check_references(self, content: str) -> Dict:
        """2. 引用校验"""
        result = {"status": "pass", "details": []}
        
        # 检查角色名、地点名引用
        character_pattern = r"[角色名：](.+?)[，,。]"
        location_pattern = r"[地点名：](.+?)[，,。]"
        
        characters = re.findall(character_pattern, content)
        locations = re.findall(location_pattern, content)
        
        if not characters:
            result["details"].append("警告：未检测到角色名引用")
        
        return result
    
    def _check_word_count(self, content: str, metadata: Dict = None) -> Dict:
        """字数检查（09-29 软化：soft_min~min_words 区间静默通过，不逼灌水）。

        - 字数 < soft_min*(1-范围)  → fail（P1，真过短/信息密度不足）
        - soft_min ~ min_words      → 静默 pass（min_words 是写作目标，不是门禁）
        - 字数 > max_words*(1+范围) → warning（P1，超标）
        """
        result = {"status": "pass", "details": []}
        word_count = len(re.sub(r"\s+", "", content))
        config = GATE_CONFIG["word_count"]
        soft_min = config.get("soft_min", config["min_words"])

        if word_count < soft_min * (1 - config["flexible_range"]):
            result["status"] = "fail"
            result["details"].append(f"字数过短：{word_count} < 软下限 {soft_min}（信息密度不足）")
        elif word_count > config["max_words"] * (1 + config["flexible_range"]):
            result["status"] = "warning"
            result["details"].append(f"字数超标：{word_count} > {config['max_words']}（考虑拆分）")

        return result
    
    def _check_fact_consistency(self, content: str, chapter_file: str) -> Dict:
        """事实一致性检查（BUG 6：修前 p0_gates 声明了此 gate 但无任何实现）。

        两条可真实检测的冲突：
        1. 提前引用：本章引用了「来源章节编号 > 本章编号」的事实 → 剧情时间线倒流
        2. 提前揭示：账本中标记 hidden / planned（未揭示）的实体出现在本章正文
        """
        result = {"status": "pass", "details": []}

        m = re.search(r"chapter[-_]?(\d+)", os.path.basename(str(chapter_file)))
        if not m:
            return result
        chap_no = int(m.group(1))

        ledger_path = self.project_dir.parent.parent / "ledger" / self.project_id / "facts.json"
        if not ledger_path.exists():
            return result
        try:
            raw = json.load(open(str(ledger_path), encoding="utf-8"))
        except Exception:
            return result
        facts = list(raw.values()) if isinstance(raw, dict) else raw

        for f in facts:
            if not isinstance(f, dict):
                continue
            body = str(f.get("content", ""))
            # 实体名 = 冒号前部分；剥离「（隐藏）」「（待创作）」等注记，
            # 否则无法与正文中的真实实体名匹配（修前 "混沌体（隐藏）" 匹配不到 "混沌体"）
            name = body.split("：")[0].strip()
            name = re.sub(r"[（(][^（）()]*[)）]", "", name).strip()
            if not name or len(name) > 10:
                continue
            status = str(f.get("status", ""))

            src_m = re.search(r"chapter[-_]?(\d+)", str(f.get("source", "")))
            src_no = int(src_m.group(1)) if src_m else None

            if src_no and src_no > chap_no:
                result["status"] = "fail"
                result["details"].append(
                    f"事实冲突：第{chap_no}章引用了第{src_no}章才记录的事实「{name}」"
                    f"（来源 {f.get('source')}，状态 {status}）")
                continue

            if status in ("hidden", "planned") and name in content:
                result["status"] = "fail"
                result["details"].append(
                    f"事实冲突：「{name}」在账本中状态为 {status}（未揭示），"
                    f"却在第{chap_no}章正文出现")

        return result

    def _check_forbidden_words(self, content: str) -> Dict:
        """4. 禁用词检查（独立门禁；修前此函数名为 _check_unknown_entities）"""
        result = {"status": "pass", "details": []}
        
        # 检查禁用词
        # 09-29 分级：去掉「最后」（序数用法"最后一口/最后一刀"被误伤）；
        # 议论文总结腔「最后，…」改由 cliche 检测（CLICHE_PATTERNS）按句首拦截。
        forbidden_words = ["首先", "其次", "综上所述"]
        for word in forbidden_words:
            if word in content:
                result["status"] = "warning"
                result["details"].append(f"检测到禁用词：{word}")
        
        return result
    
    def _check_description_consistency(self, content: str) -> Dict:
        """5. 描写一致性检查"""
        result = {"status": "pass", "details": []}
        
        # 检查段落长度
        paragraphs = content.split("\n")
        long_paragraphs = [p for p in paragraphs if len(p) > 300]
        
        if long_paragraphs:
            result["status"] = "warning"
            result["details"].append(f"检测到{len(long_paragraphs)}个超长段落（>300字）")
        
        return result
    
    def _check_blueprint(self, content: str, metadata: Dict) -> Dict:
        """6. 蓝图出场检查"""
        result = {"status": "pass", "details": []}

        if "title" not in metadata:
            result["status"] = "fail"
            result["details"].append("缺少章节标题")

        return result

    def _check_hook(self, content: str) -> Dict:
        """8. 章末钩子检查"""
        result = {"status": "pass", "details": [], "has_hook": False}

        paragraphs = content.split("\n")
        ending_paragraphs = paragraphs[-10:] if len(paragraphs) >= 10 else paragraphs

        hook_patterns = [
            r"突然", r"竟然", r"原来", r"没想到", r"居然",
            r"危险", r"威胁", r"杀意", r"阴谋", r"背后", r"暗中",
            r"神秘", r"未知", r"身份", r"真相", r"秘密",
            r"眼神", r"目光", r"神色", r"沉默",
            r"等等", r"且慢", r"站住", r"等一下",
            r"如果", r"难道", r"怎么",
            r"剑", r"醒了", r"异变", r"惊变", r"骤变", r"脸色",
            r"下一章", r"预告",
            r"记号", r"不一样", r"不止", r"另一", r"下面", r"底下", r"藏着", r"够不到",
        ]

        combined_text = " ".join(ending_paragraphs)
        hits = []
        for pattern in hook_patterns:
            matches = re.findall(pattern, combined_text)
            if matches:
                hits.extend(matches)

        if hits:
            result["has_hook"] = True
            result["details"].append(f"检测到{len(hits)}处潜在钩子信号：{hits[:5]}...")
        else:
            result["status"] = "warning"
            result["details"].append("警告：章末未检测到明显钩子")

        return result
    
    def _check_logic_review(self, chapter_file: str) -> Dict:
        """9. 逻辑审查检查（调用 logic-review.py）"""
        result = {"status": "pass", "details": []}
        try:
            import subprocess
            cmd = [sys.executable, "-m", "tools.logic-review", "--file", chapter_file]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if proc.returncode != 0:
                result["status"] = "fail"
                output = proc.stderr if proc.stderr else proc.stdout
                for line in output.split("\n"):
                    if "❌" in line or "严重" in line:
                        result["details"].append(line.strip())
        except Exception as e:
            result["status"] = "pass"
            result["details"].append(f"logic-review 执行失败: {e}")
        return result

    def _check_darkthread(self, chapter_file: str) -> Dict:
        """10. 暗线追踪检查（检查伏笔是否推进）"""
        result = {"status": "pass", "details": [], "foreshadowing_pushed": 0}
        try:
            from pathlib import Path
            darkthreads_dir = self.project_dir / "dark-threads"
            if not darkthreads_dir.exists():
                return result
            
            # 找到最新的快照
            snapshots = list(darkthreads_dir.glob("ch*_snapshot.yaml"))
            if not snapshots:
                return result
            
            latest = max(snapshots, key=lambda p: p.stat().st_mtime)
            
            # 读取当前章节内容
            content = Path(chapter_file).read_text(encoding="utf-8")
            
            # 检查是否提及了活跃的伏笔
            import yaml
            snapshot = yaml.safe_load(latest.read_text())
            active_foreshadowing = snapshot.get("foreshadowing_active", [])
            
            pushed = 0
            for foreshadow in active_foreshadowing:
                if foreshadow[:10] in content or foreshadow[:5] in content:
                    pushed += 1
            
            result["foreshadowing_pushed"] = pushed
            if pushed == 0 and len(active_foreshadowing) > 0:
                result["status"] = "warning"
                result["details"].append(f"未推进任何伏笔（活跃{len(active_foreshadowing)}条）")
        except Exception as e:
            result["status"] = "pass"
            result["details"].append(f"暗线追踪检查失败: {e}")
        return result

    def _check_cliche(self, content: str) -> Dict:
        """套路/AI腔检测（P2 建议级，不阻断）——09-29 多模型测试新增。"""
        result = {"status": "pass", "details": []}
        if not GATE_CONFIG.get("cliche", {}).get("enabled", True):
            return result
        for pat, label in CLICHE_PATTERNS:
            if pat.search(content):
                result["details"].append(label)
        # A（09-29）：日历报数检测——把『淡化时间、事件驱动』洞察门禁化
        n_report = len(TIME_REPORT_RE.findall(content))
        if n_report > TIME_REPORT_THRESHOLD:
            result["details"].append(
                f"日历报数 {n_report} 处『第X天/周』（疑似流水账，建议事件驱动/淡化时间）")
        # B（09-29）：场景跳跃检测——把『连贯过渡』洞察门禁化
        n_jumps = sum(1 for pat, _ in SCENE_JUMP_PATTERNS if pat.search(content))
        if n_jumps > SCENE_JUMP_THRESHOLD:
            result["details"].append(
                f"场景跳跃 {n_jumps} 处（疑似硬切，建议加过渡桥段：行走/等待/天气变化）")
        if result["details"]:
            result["status"] = "fail"  # P2 gate：fail → 进 p2_suggestions 桶，不阻断
        return result

    def _check_ai_tone(self, chapter_file: str) -> Dict:
        """8. AI味检查"""
        result = {"status": "pass", "details": [], "tier_1a": None}
        config = GATE_CONFIG["ai_tone"]

        try:
            import subprocess
            proc = subprocess.run(
                [sys.executable,
                 str(Path(__file__).parent / "novel-humanizer.py"),
                 "--chapter-file", chapter_file, "--json"],
                capture_output=True, text=True, timeout=30
            )
            data = json.loads(proc.stdout)
            tier_1a = data.get("tier_1a", 0)
            result["tier_1a"] = tier_1a

            threshold = config["max_score"]
            if tier_1a > threshold * (1 + config["flexible_range"]):
                result["status"] = "fail"
                result["details"].append(
                    f"AI味严重超标：tier_1a={tier_1a} > {int(threshold * (1 + config['flexible_range']))}"
                )
            elif tier_1a > threshold:
                result["status"] = "warning"
                result["details"].append(
                    f"AI味轻微超标：tier_1a={tier_1a}，阈值={threshold}"
                )
        except json.JSONDecodeError:
            result["status"] = "fail"
            result["details"].append("AI味检查失败：humanizer 输出非 JSON")
        except subprocess.TimeoutExpired:
            result["status"] = "fail"
            result["details"].append("AI味检查超时（>30s）")
        except Exception as e:
            result["status"] = "fail"
            result["details"].append(f"AI味检查异常：{e}")

        return result

    def _classify_gate(self, gate_name: str) -> str:
        """将门禁归类到P0/P1/P2级别"""
        if gate_name in self.p0_gates:
            return "P0"
        elif gate_name in self.p1_gates:
            return "P1"
        else:
            return "P2"
    
    def _evaluate_results(self, checks: Dict, flexible: bool) -> bool:
        """评估检查结果（四档质量债务 + 两种阻断机制）"""
        p0_failures = []
        p1_warnings = []
        p2_suggestions = []

        # BUG 1 修复：修前 data_integrity_error 全文只有 3 处引用且全是读取、从未赋值，
        # 导致阻断层 0% 生效——20/20 章无条件 passed=True，哪怕有 gate 判 fail。
        block_gates = getattr(self, "BLOCK_GATES",
                              ["fact_consistency", "ai_tone", "protocol"])
        data_integrity_error = None
        for gname in block_gates:
            g = checks.get(gname)
            if isinstance(g, dict) and g.get("status") == "fail":
                data_integrity_error = (
                    f"{gname}: " + "；".join(str(d) for d in g.get("details", [])[:3]))
                break

        for check_name, check_result in checks.items():
            if check_result.get("status") == "skipped":
                continue  # 跳过项不参与判定
            
            level = self._classify_gate(check_name)

            if check_result["status"] == "fail":
                if level == "P0":
                    p0_failures.extend(check_result.get("details", []))
                elif level == "P1":
                    p1_warnings.extend(check_result.get("details", []))
                else:
                    p2_suggestions.extend(check_result.get("details", []))

            elif check_result["status"] == "warning":
                if level == "P0":
                    p0_failures.extend(check_result.get("details", []))
                elif level == "P1":
                    p1_warnings.extend(check_result.get("details", []))
                else:
                    p2_suggestions.extend(check_result.get("details", []))

        results = {
            "p0_failures": p0_failures,
            "p1_warnings": p1_warnings,
            "p2_suggestions": p2_suggestions,
            "warnings": p1_warnings + p2_suggestions,
            "errors": p0_failures,
            "data_integrity_error": data_integrity_error,
            "debts_recorded": len(p0_failures) + len(p1_warnings) + len(p2_suggestions),
            "will_block": False,
            "block_reason": None,
        }

        # BUG 7 修复：修前此 results dict 构建后从未返回（函数只 return bool），
        # will_block / block_reason / debts_recorded 整个结构被丢弃。
        # 现挂到 self.last_evaluation，由 check()/check_modify() 合并进返回结果。
        results["will_block"] = bool(data_integrity_error)
        results["block_reason"] = "data_integrity_failure" if data_integrity_error else None
        results["continue_creation"] = not data_integrity_error
        self.last_evaluation = results

        if data_integrity_error:
            return False
        return True
    
    def _collect_warnings(self, checks: Dict) -> List[str]:
        """收集所有警告（按级别分类）"""
        warnings = []
        p1_warnings = []
        p2_warnings = []
        
        for check_name, check_result in checks.items():
            if check_result.get("status") == "skipped":
                continue
            if check_result["status"] == "warning":
                detail = "; ".join(str(d) for d in (check_result.get("details") or []))
                detail = detail.strip()
                if not detail:      # BUG 5：跳过空 detail
                    continue
                msg = f"[{self._classify_gate(check_name)}] {detail}"
                warnings.append(msg)
                if self._classify_gate(check_name) == "P1":
                    p1_warnings.append(msg)
                else:
                    p2_warnings.append(msg)
        
        return {
            "all": warnings,
            "p1": p1_warnings,
            "p2": p2_warnings,
        }
    
    def _collect_errors(self, checks: Dict) -> Dict:
        """收集所有错误（按级别分类）

        BUG 2 修复：修前只有 all 与 p0 两个桶，没有 p1/p2。
        而 summary 统计与 generate_fix_order 都读 errors["p1"]/errors["p2"]
        → 字数等 P1/P2 失败既进不了 summary，也进不了修复顺序列表。
        """
        errors = []
        p0_errors, p1_errors, p2_errors = [], [], []
        
        for check_name, check_result in checks.items():
            if not isinstance(check_result, dict):
                continue
            if check_result.get("status") == "skipped":
                continue
            if check_result["status"] != "fail":
                continue
            level = self._classify_gate(check_name)
            detail = "; ".join(str(d) for d in (check_result.get("details") or []))
            detail = detail.strip()
            if not detail:      # BUG 5：修前 details 为空时产出 "[P2] " 空项
                continue
            msg = f"[{level}] {detail}"
            errors.append(msg)
            {"P0": p0_errors, "P1": p1_errors}.get(level, p2_errors).append(msg)
        
        return {
            "all": errors,
            "p0": p0_errors,
            "p1": p1_errors,
            "p2": p2_errors,
        }
    
    def _load_chapter(self, chapter_file: str) -> Tuple[str, Dict]:
        """加载章节文件和元数据"""
        try:
            with open(chapter_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            metadata = {}
            if content.startswith("---"):
                lines = content.split("\n")
                in_metadata = False
                for line in lines[1:]:
                    if line == "---":
                        in_metadata = False
                        break
                    if ":" in line:
                        key, value = line.split(":", 1)
                        metadata[key.strip()] = value.strip()
                
                content_start = content.find("\n---\n") + 5
                content = content[content_start:].strip()
            
            return content, metadata
        except Exception as e:
            print(f"Error loading chapter: {e}", file=sys.stderr)
            return None, {}
    
    def _save_result(self, result: Dict):
        """保存检查结果"""
        result_dir = self.project_dir / "reports"
        result_dir.mkdir(parents=True, exist_ok=True)

        result_file = result_dir / f"gate-check-{int(time.time())}.json"
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

        self._sync_to_ledger(result)
        self._emit_gate_event(result)

    def _emit_gate_event(self, result: Dict):
        """门禁通过时写入事件总线，触发世界包同步链（event-bus.py consume 消费）

        只在 passed=True 时发射 CHAPTER_GATE_PASSED。失败不发射——
        没有注册对应链，发了只会在 .events/ 里堆积未消费事件污染 status。
        """
        if not result.get("passed"):
            return
        try:
            cf = str(result.get("chapter_file", ""))
            # 从文件名提取章节号：chapter-001.md → 1
            m = re.search(r'(\d+)', Path(cf).stem)
            chapter = int(m.group(1)) if m else None
            payload = {
                "chapter": chapter,
                "passed": True,
                "mode": result.get("mode", "write"),
                "chapter_file": cf,
                "summary": result.get("summary", {}),
            }
            cmd = [
                sys.executable, "/var/minis/shared/event-bus.py", "emit",
                "--source", self.project_id,
                "--type", "CHAPTER_GATE_PASSED",
                "--payload", json.dumps(payload, ensure_ascii=False),
                "--quiet",
            ]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            if r.returncode == 0:
                # 契约：诊断信息进 stderr，stdout 保持纯 JSON（修前污染 stdout 导致机器端 JSON.parse 失败）
                import sys as _sys
                print(f"📡 已发射事件 CHAPTER_GATE_PASSED (ch{chapter}) → .events/{self.project_id}.jsonl", file=_sys.stderr)
            else:
                print(f"⚠️ 事件发射失败: {r.stderr.strip()[:200]}", file=sys.stderr)
        except Exception as e:
            # 事件失败绝不能阻断门禁结果输出
            print(f"⚠️ 事件发射异常: {e}", file=sys.stderr)
    
    def _sync_to_ledger(self, result: Dict):
        """将门禁结果同步到fact-ledger"""
        try:
            from fact_ledger import FactLedger
            ledger = FactLedger(self.project_id)
            ledger.add_fact(
                category="gate_check",
                content=f"门禁结果: {'通过' if result['passed'] else '未通过'} | 模式:{result.get('mode','write')} | P0阻断:{len(result.get('p0_failures', []))} | P1警告:{len(result.get('p1_warnings', []))}",
                source=result['chapter_file']
            )
        except ImportError:
            pass
        except Exception as e:
            print(f"⚠️ 同步到fact-ledger失败: {e}", file=sys.stderr)

    def generate_fix_order(self, result: Dict) -> list:
        """按优先级生成修复建议列表（D2 实测用）

        优先级规则（来自 TEAM.md §并发故障降级策略）：
        设定矛盾(P0) > 角色掉线(P0) > AI味(P0) > 字数(P1) > 禁用词(P1) > 钩子(P1) > 细节建议(P2)

        输入 result 的 errors/warnings 字段是字符串列表，如 "[P1] 字数不足：..."
        """
        import re as _re
        GATE_LABELS = {
            "事实冲突": "fact_consistency",
            "设定矛盾": "fact_consistency",
            "角色掉线": "character_consistency",
            "AI味": "ai_tone",
            "字数不足": "word_count",
            "禁用词": "forbidden_words",
            "钩子": "hook",
            "协议": "protocol",
            "蓝图": "blueprint",
            "一致": "consistency",
            "引用": "reference",
            "实体": "unknown_entities",
            "描述一致": "description_consistency",
            "逻辑": "logic_review",
            "暗线": "darkthread",
        }

        # 同级别次级优先级：TEAM.md §并发故障降级策略 声明的完整链
        # 修前缺陷：sort 只用 priority(1/2/3)，同级别内退化为插入顺序，
        #   即「设定矛盾优先于AI味」从未生效（见 TEAM.md v0.60 D2a）。
        GATE_SUB_PRIORITY = {
            "fact_consistency": 1, "character_consistency": 2, "ai_tone": 3,
            "word_count": 4, "forbidden_words": 5, "hook": 6,
            "protocol": 7, "blueprint": 8, "consistency": 9,
            "reference": 10, "unknown_entities": 11,
            "description_consistency": 12, "logic_review": 13, "darkthread": 14,
        }
        SUB_FALLBACK = 99

        def parse_issue(line: str):
            """从 '[P1] 钩子缺失：...' 提取 level/gate/label/detail"""
            m = _re.match(r'\[(P[0-9])\]\s*(.+)', line)
            if not m:
                return None
            level = m.group(1)
            text = m.group(2).strip()
            # 提取 gate：查找 keyword → gate 映射
            gate = None
            for keyword, g in GATE_LABELS.items():
                if keyword in text:
                    gate = g
                    break
            # label = gate关键字 + 冒号后内容（完整描述）
            colon_idx = text.find("：") if "：" in text else text.find(":")
            if colon_idx >= 0:
                label = text[:colon_idx]  # "钩子缺失"
                detail = text[colon_idx+1:].strip()
            else:
                label = text
                detail = ""
            return {"level": level, "gate": gate or "unknown", "label": label, "detail": detail}

        def item_priority(level):
            if "P0" in level: return 1
            if "P1" in level: return 2
            return 3

        fix_list = []
        seen = set()
        for section in ["errors", "warnings"]:
            sec = result.get(section, {})
            for level_key in ["p0", "p1", "p2"]:
                items = sec.get(level_key, [])
                for line in items:
                    parsed = parse_issue(str(line))
                    if not parsed:
                        continue
                    # 修前用 gate 去重：同 gate 的第二个问题被静默丢弃（D2b）。
                    # 改为按 (level, gate, label, detail) 去重，只合并真正的重复行。
                    key = (parsed["level"], parsed["gate"], parsed["label"], parsed["detail"])
                    if key in seen:
                        continue
                    seen.add(key)
                    fix_list.append({
                        "priority": item_priority(parsed["level"]),
                        "sub_priority": GATE_SUB_PRIORITY.get(parsed["gate"], SUB_FALLBACK),
                        "level": parsed["level"],
                        "gate": parsed["gate"],
                        "label": parsed["label"],
                        "detail": parsed["detail"],
                    })
        fix_list.sort(key=lambda x: (x["priority"],
                                     GATE_SUB_PRIORITY.get(x["gate"], SUB_FALLBACK)))
        return fix_list

    # ========================================================================
    # 审核状态机方法（方案C+ 新增）
    # ========================================================================

    def get_review_status(self, chapter_num: int) -> Dict:
        """
        获取章节审核状态

        返回：
            {
                "chapter": int,
                "status": "待审核" | "已审核" | "审核驳回",
                "triggered_at": str,
                "no_feedback_rounds": int,
                "reviewer_comment": str,
            }
        """
        status_file = self.status_dir / f"review-ch{chapter_num:03d}.json"
        if not status_file.exists():
            return {
                "chapter": chapter_num,
                "status": "未初始化",
                "triggered_at": None,
                "no_feedback_rounds": 0,
                "reviewer_comment": None,
            }
        return json.loads(status_file.read_text(encoding='utf-8'))

    def set_review_status(self, chapter_num: int, status: str, comment: str = None):
        """
        设置章节审核状态

        参数：
            chapter_num: 章节号
            status: "待审核" | "已审核" | "审核驳回"
            comment: 审核意见（驳回时必须）
        """
        status_file = self.status_dir / f"review-ch{chapter_num:03d}.json"
        self.status_dir.mkdir(parents=True, exist_ok=True)  # 惰性创建（BUG 10）
        data = {
            "chapter": chapter_num,
            "status": status,
            "triggered_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "no_feedback_rounds": 0,
            "reviewer_comment": comment,
        }
        status_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def trigger_review(self, chapter_num: int) -> Dict:
        """
        触发审核（创作完成 → 待审核）

        返回：
            {"success": bool, "chapter": int, "message": str}
        """
        status = self.get_review_status(chapter_num)
        if status["status"] == "待审核":
            return {
                "success": False,
                "chapter": chapter_num,
                "message": f"第{chapter_num}章已在待审核队列中"
            }
        if status["status"] == "已审核":
            return {
                "success": False,
                "chapter": chapter_num,
                "message": f"第{chapter_num}章已完成审核，无需重复触发"
            }

        self.set_review_status(chapter_num, "待审核")
        return {
            "success": True,
            "chapter": chapter_num,
            "message": f"第{chapter_num}章已加入审核队列"
        }

    def auto_approve(self, chapter_num: int) -> Dict:
        """
        自动通过（连续3轮无反馈 → 已审核）

        返回：
            {"success": bool, "chapter": int, "message": str}
        """
        status = self.get_review_status(chapter_num)
        if status["status"] != "待审核":
            return {
                "success": False,
                "chapter": chapter_num,
                "message": f"第{chapter_num}章不在待审核状态"
            }

        # 检查是否达到3轮无反馈阈值
        if status.get("no_feedback_rounds", 0) < 3:
            return {
                "success": False,
                "chapter": chapter_num,
                "message": f"第{chapter_num}章仅无反馈{status.get('no_feedback_rounds', 0)}轮，需达到3轮"
            }

        self.set_review_status(chapter_num, "已审核", comment="连续3轮无反馈，默认通过")
        return {
            "success": True,
            "chapter": chapter_num,
            "message": f"第{chapter_num}章审核默认通过（连续3轮无反馈）"
        }

    def reject_review(self, chapter_num: int, reason: str) -> Dict:
        """
        驳回审核（审核发现重大问题 → 审核驳回）

        返回：
            {"success": bool, "chapter": int, "message": str}
        """
        status = self.get_review_status(chapter_num)
        if status["status"] != "待审核":
            return {
                "success": False,
                "chapter": chapter_num,
                "message": f"第{chapter_num}章不在待审核状态"
            }

        self.set_review_status(chapter_num, "审核驳回", comment=reason)
        return {
            "success": True,
            "chapter": chapter_num,
            "message": f"第{chapter_num}章审核驳回：{reason}"
        }

    def increment_no_feedback(self, chapter_num: int) -> Dict:
        """
        增加无反馈轮次（每次调用后无回复时增加）

        返回：
            {"chapter": int, "rounds": int, "should_auto_approve": bool}
        """
        status = self.get_review_status(chapter_num)
        if status["status"] != "待审核":
            return {"chapter": chapter_num, "rounds": 0, "should_auto_approve": False}

        rounds = status.get("no_feedback_rounds", 0) + 1
        status_file = self.status_dir / f"review-ch{chapter_num:03d}.json"
        self.status_dir.mkdir(parents=True, exist_ok=True)  # 惰性创建（BUG 10）
        data = json.loads(status_file.read_text(encoding='utf-8'))
        data["no_feedback_rounds"] = rounds
        status_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

        return {
            "chapter": chapter_num,
            "rounds": rounds,
            "should_auto_approve": rounds >= 3,
        }

    def get_block_status(self, chapter_num: int) -> Dict:
        """
        检查章节是否阻塞下一章创作

        返回：
            {
                "blocked": bool,
                "reason": str,
                "status": str,
            }
        """
        status = self.get_review_status(chapter_num)
        if status["status"] == "待审核":
            return {
                "blocked": True,
                "reason": f"第{chapter_num}章处于待审核状态，需等待审核结果或连续3轮无反馈自动通过",
                "status": "待审核",
            }
        if status["status"] == "审核驳回":
            return {
                "blocked": True,
                "reason": f"第{chapter_num}章审核驳回，需回炉修改后重新提交",
                "status": "审核驳回",
            }
        return {
            "blocked": False,
            "reason": None,
            "status": status["status"],
        }


def main():
    import time
    
    if len(sys.argv) < 3:
        print("Usage: python gate-check.py check --chapter <num> --file <file> [--flexible] [--mode write|modify]")
        print("       python gate-check.py status --novel-id <id> --chapter <num>")
        print("       python gate-check.py trigger --novel-id <id> --chapter <num>")
        print("       python gate-check.py approve --novel-id <id> --chapter <num>")
        print("       python gate-check.py reject --novel-id <id> --chapter <num> --reason <reason>")
        print("       python gate-check.py block-status --novel-id <id> --chapter <num>")
        sys.exit(1)
    
    # 解析参数
    args = sys.argv[1:]
    
    # 检查是否为新状态机命令
    if args[0] == "status":
        # 状态查询
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--novel-id", default="my-novel")
        parser.add_argument("--chapter", required=True, type=int)
        parsed = parser.parse_args(args[1:])
        
        checker = GateChecker(parsed.novel_id)
        result = checker.get_review_status(parsed.chapter)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    
    elif args[0] == "trigger":
        # 触发审核
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--novel-id", default="my-novel")
        parser.add_argument("--chapter", required=True, type=int)
        parsed = parser.parse_args(args[1:])
        
        checker = GateChecker(parsed.novel_id)
        result = checker.trigger_review(parsed.chapter)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result["success"] else 1)
    
    elif args[0] == "approve":
        # 自动通过
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--novel-id", default="my-novel")
        parser.add_argument("--chapter", required=True, type=int)
        parsed = parser.parse_args(args[1:])
        
        checker = GateChecker(parsed.novel_id)
        result = checker.auto_approve(parsed.chapter)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result["success"] else 1)
    
    elif args[0] == "reject":
        # 驳回
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--novel-id", default="my-novel")
        parser.add_argument("--chapter", required=True, type=int)
        parser.add_argument("--reason", required=True, help="驳回原因")
        parsed = parser.parse_args(args[1:])
        
        checker = GateChecker(parsed.novel_id)
        result = checker.reject_review(parsed.chapter, parsed.reason)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result["success"] else 1)
    
    elif args[0] == "block-status":
        # 阻塞状态
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--novel-id", default="my-novel")
        parser.add_argument("--chapter", required=True, type=int)
        parsed = parser.parse_args(args[1:])
        
        checker = GateChecker(parsed.novel_id)
        result = checker.get_block_status(parsed.chapter)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if not result["blocked"] else 1)
    
    elif args[0] == "increment":
        # 增加无反馈轮次
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--novel-id", default="my-novel")
        parser.add_argument("--chapter", required=True, type=int)
        parsed = parser.parse_args(args[1:])
        
        checker = GateChecker(parsed.novel_id)
        result = checker.increment_no_feedback(parsed.chapter)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    
    else:
        # 原有命令解析逻辑
        chapter_num = None
        chapter_file = None
        flexible = False
        novel_id = "my-novel"
        mode = "write"  # write（完整）或 modify（修改）
        
        i = 0
        while i < len(args):
            if args[i] == "--chapter" and i + 1 < len(args):
                chapter_num = args[i + 1]
                i += 2
            elif args[i] == "--novel-id" and i + 1 < len(args):
                # BUG 9 修复：修前 check 命令完全不解析 --novel-id，
                # 硬编码 GateChecker("my-novel") → 任何项目的门禁都读 my-novel
                # 的账本与事件（多项目隔离在门禁层断裂）
                novel_id = args[i + 1]
                i += 2
            elif args[i] == "--file" and i + 1 < len(args):
                chapter_file = args[i + 1]
                i += 2
            elif args[i] == "--flexible":
                flexible = True
                i += 1
            elif args[i] == "--mode" and i + 1 < len(args):
                mode = args[i + 1]
                i += 2
            elif args[i] == "--fix-order":
                i += 1
            else:
                i += 1
        
        if not chapter_file:
            print("Error: --file is required", file=sys.stderr)
            sys.exit(1)
        
        # 执行检查
        checker = GateChecker(novel_id)
        result = checker.check(chapter_file, flexible, mode)

        # D2：--fix-order 模式：输出按优先级排序的修复建议（并发降级策略实测）
        if "--fix-order" in args:
            fixes = checker.generate_fix_order(result)
            if fixes:
                print(f"\n🔧 修复顺序（D2 降级策略）：", file=sys.stderr)
                for i, fix in enumerate(fixes, 1):
                    print(f"   {i}. [{fix['level']}] {fix['label']}（gate={fix['gate']}）: {fix['detail'][:80]}", file=sys.stderr)
            else:
                print("\n✅ 无问题，无需修复。", file=sys.stderr)

        # 事件发射：门禁通过 → 触发世界包同步扫描
        if result.get("passed"):
            try:
                import time as _time
                _events_dir = Path(__file__).parent.parent / ".events"
                _events_dir.mkdir(parents=True, exist_ok=True)
                _events_file = _events_dir / f"{novel_id}.jsonl"  # BUG 9 配套：事件也按项目分文件
                _ch_num = int(chapter_num) if chapter_num else 1
                _event = {"event": "CHAPTER_GATE_PASSED",
                          "chapter": _ch_num,
                          "timestamp": _time.strftime("%Y-%m-%dT%H:%M:%S")}
                with open(_events_file, "a", encoding="utf-8") as _f:
                    _f.write(json.dumps(_event, ensure_ascii=False) + "\n")
            except Exception:
                pass

        # 输出结果
        print(json.dumps(result, ensure_ascii=False, indent=2))

        # 退出码
        sys.exit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
