#!/usr/bin/env python3
"""封面流水线 · 去水印 → 裁 2.35:1 → 叠标题 → OCR 门禁自检

对应 gzh-team/TEAM.md §3.6「封面与配图生成」与 REVIEW.md H11-H13。

用法:
  python3 cover-pipeline.py --src <图> --wm <x1,y1,x2,y2> --title <主标题>
         [--sub <副标题>] [--out <输出>] [--keep-wm]

示例（sensenova 3072x1376，水印在右上角）:
  python3 cover-pipeline.py \
    --src /var/minis/attachments/xxx.png \
    --wm 2700,0,3072,150 \
    --title "你的 AI 文章标注了吗？" --sub "AI 标识办法一周年"

门禁退出码：0=全绿 / 1=H11 未过（图上检出中文）/ 2=输入错误
"""
import argparse, json, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

TARGET_W, TARGET_H = 900, 383          # 公众号封面 2.35:1
FONT = '/usr/share/fonts/noto/NotoSansCJK-Bold.ttc'
PAD = 40                                # 水印覆盖区需大于 OCR bbox 的最小外扩


def check_text(path, level='fast'):
    """H11 门禁：只信 fast 级。accurate 级在纯色区会幻觉出中文。"""
    r = subprocess.run(['apple-vision', 'ocr', path, '--lang', 'zh-Hans,en',
                        '--level', level, '-q'],
                       capture_output=True, text=True, timeout=90)
    try:
        return json.loads(r.stdout).get('blocks', [])
    except json.JSONDecodeError:
        return None


def is_flat(path, box, max_colors=2):
    """像素实测：区域颜色数 ≤max_colors → 该处是纯色，OCR 检出属幻觉"""
    px = list(Image.open(path).convert('RGB').crop(box).getdata())
    return len(set(px)) <= max_colors, len(set(px)), len(px)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', required=True)
    ap.add_argument('--wm', help='水印 bbox: x1,y1,x2,y2（源图坐标）')
    ap.add_argument('--title', required=True)
    ap.add_argument('--sub', default='')
    ap.add_argument('--out', default='/var/minis/attachments/cover-out.png')
    ap.add_argument('--keep-wm', action='store_true',
                    help='保留水印（自动满足 AI 标识，但封面带角标）')
    a = ap.parse_args()

    im = Image.open(a.src).convert('RGB')
    W, H = im.size
    print(f'源图 {W}x{H}  ratio={W/H:.4f}')

    d = ImageDraw.Draw(im)
    if a.wm and not a.keep_wm:
        x1, y1, x2, y2 = (int(v) for v in a.wm.split(','))
        # 采样水印左侧背景色
        sx1 = max(x1 - 60, 0)
        patch = im.crop((sx1, y1, max(x1 - 10, sx1 + 1), y2))
        px = list(patch.getdata()) or [(255, 255, 255)]
        bg = tuple(sum(c[i] for c in px) // len(px) for i in range(3))
        d.rectangle((x1, y1, x2, y2), fill=bg)
        print(f'[去水印] 覆盖 ({x1},{y1},{x2},{y2}) 用色 {bg}  外扩≥{PAD}px 需人工确认')
    else:
        print('[去水印] 跳过 → 发布必须开后台「AI 生成内容」声明开关')

    # 中心裁 2.35:1 再缩放
    th = int(W * TARGET_H / TARGET_W)
    if th > H:                      # 源图比目标更扁 → 改裁宽度
        tw = int(H * TARGET_W / TARGET_H)
        im = im.crop(((W - tw) // 2, 0, (W - tw) // 2 + tw, H))
    else:
        top = (H - th) // 2
        im = im.crop((0, top, W, top + th))
    im = im.resize((TARGET_W, TARGET_H), Image.LANCZOS)
    print(f'[裁切] {im.size}  ratio={im.size[0]/im.size[1]:.4f}')

    # 叠标题：白字深描边，右对齐
    d = ImageDraw.Draw(im)
    f_big, f_sub = ImageFont.truetype(FONT, 36), ImageFont.truetype(FONT, 16)
    stroke = (15, 30, 40)

    def put(xy, txt, fill, font):
        x, y = xy
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                if dx or dy:
                    d.text((x + dx, y + dy), txt, fill=stroke, font=font)
        d.text((x, y), txt, fill=fill, font=font)

    b = d.textbbox((0, 0), a.title, font=f_big)
    tw_, th_ = b[2] - b[0], b[3] - b[1]
    tx, ty = TARGET_W - tw_ - 40, (TARGET_H - th_) // 2 - 15
    put((tx, ty), a.title, (255, 255, 255), f_big)
    if a.sub:
        b2 = d.textbbox((0, 0), a.sub, font=f_sub)
        put((TARGET_W - (b2[2] - b2[0]) - 40, ty + th_ + 8), a.sub,
            (220, 220, 220), f_sub)
    im.save(a.out, 'PNG')
    print(f'[输出] {a.out}')

    # OCR 门禁
    blocks = check_text(a.out, 'fast')
    if blocks is None:
        print('[H11] OCR 调用失败，人工复核')
        return 2
    mine = {a.title, a.sub} - {''}
    print('[H11] fast OCR 检出:')
    fail = False
    for b in blocks:
        t = b['text'].strip()
        if t in mine or not t:
            print(f'   ✓ [{t}] 自加文字')
            continue
        x, y, w, h = b['bbox']
        box = (int(x * TARGET_W), int(y * TARGET_H),
               int((x + w) * TARGET_W), int((y + h) * TARGET_H))
        flat, ncol, npx = is_flat(a.out, box)
        if b.get('confidence', 0) < 0.5 and flat:
            print(f'   ⚠ [{t}] conf={b["confidence"]:.2f} 区域仅 {ncol} 色/{npx}px → OCR 幻觉')
        else:
            print(f'   ✗ [{t}] conf={b.get("confidence",0):.2f} 区域 {ncol} 色 → 真实文字，H11 未过')
            fail = True
    if not blocks:
        print('   （空）')
    print(f'\n门禁结论: {"H11 FAIL — 退回重出" if fail else "全绿 ✅"}')
    print('[H13] 提示: 去水印封面 → 发布开「AI 生成内容」声明开关')
    return 1 if fail else 0


sys.exit(main())
