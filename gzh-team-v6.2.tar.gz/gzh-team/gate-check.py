#!/usr/bin/env python3
# G5 门禁实测脚本 —— 精确计数类不采信模型自报（见 VALIDATION §9）
import sys,re,json
t=open(sys.argv[1]).read()
# 终止节补齐「结尾」「发布」：规范(TEAM.md §3.4)要求文章有 ## 结尾 节。
# 当节序为 正文→结尾 时，旧列表缺 结尾 会把结尾字数算进正文，H8 虚高。
# 实测：对历史 5 篇影响为 0（它们的 配图/AI参与 节在 结尾 之前先终止）；
#       对 A/B 生成的 正文→结尾 结构影响 60-300 字（2026-09-18 实测）。
m=re.search(r'##\s*正文(.*?)(?=\n#{2,3}\s*(配图|缺口判断|AI 参与|自检|结尾|发布))',t,re.S)
body=m.group(1) if m else t
zh=len(re.findall(r'[\u4e00-\u9fff]',body))
paras=[p.strip() for p in re.split(r'\n\s*\n',body) if p.strip() and not p.strip().startswith(('**','##','【'))]
sents=lambda p:len([x for x in re.split(r'[。！？；]',re.sub(r'\*\*|【金句】','',p)) if x.strip()])
over=[(i+1,sents(p),p[:18]) for i,p in enumerate(paras) if sents(p)>3]
BANNED=['首先','其次','此外','总而言之','不可否认','需要关注的是','接下来','需要注意的是','换句话说']
hits=[w for w in BANNED if w in body]
meta=[w for w in ['这里多余','刚才说','删掉。','多余，删'] if w in body]
titles=re.findall(r'（[^）]+）',t)
# 阈值：备选阶段要求 5 个（覆盖 5 类策略），已选阶段要求 ≥1（选定标题须标注策略）
title_min=1 if '已选标题' in t else 5
# H-注入：草稿不得含行首注入标记（system-reminder / </result> / <system> 等）
# 防模型返回尾部被拼接伪指令流进发布产物；清洗漏网或绕过 sanitize 时兜底
INJECT_RE=re.compile(r'^\s*(?:system[-_ ]?reminder|system\s*prompt|system\s*:|</?(?:result|system|minis)\b[^>]*>|<\|im_end\|>|ignore\s+(?:all\s+)?previous\s+instructions)',re.I|re.M)
inject_hits=INJECT_RE.findall(t)
# 占位符统一规则（contracts.md H4，2026-09-19 借鉴专业文档生成团队）
# [待填写] = 预期行为（资料不足如实标记，对齐严审之"不扣分"），但必须在文末 ## 信息缺口声明 小节显式列出
# 非标占位符（XX/___/xxx/待补/TBD）= 内容缺陷（主笔没处理完就交）→ FAIL
PLACEHOLDER_RE=re.compile(r'XX+|xx+|_{2,}|TBD|tbd|待补')
ph_hits=PLACEHOLDER_RE.findall(t)
todo_hits=t.count('[待填写]')
has_gap_section='信息缺口声明' in t
res={'正文字数':zh,'字数达标':zh>=800,'段落数':len(paras),
     '超3句段落数':len(over),'超标明细':over,'禁用词命中':hits,
     '元话语命中':meta,'标题策略数':len(titles),'标题策略阈值':title_min,
     'AI参与标注':bool(re.search(r'AI\s*参与(程度|占比)',''.join(t)) or 'AI 参与' in t),
     '注入残留':len(inject_hits),
     '非标占位符':ph_hits,'待填写数':todo_hits,'有缺口声明':has_gap_section}
for k,v in res.items(): print(f'{k}: {v}')
fails=[]
if zh<800: fails.append(f'H8 字数 {zh}<800')
if over: fails.append('H9 %d 段超 3 句'%len(over))
if hits: fails.append('H-禁 %s'%','.join(hits))
if meta: fails.append('H-元话语 %s'%','.join(meta))
if len(titles)<title_min: fails.append('标题策略 %d<%d'%(len(titles),title_min))
if inject_hits: fails.append('H-注入 %d 处残留（须过 sanitize 净化）'%len(inject_hits))
if ph_hits: fails.append('H-占位符 非标 %d 处: %s（须用 [待填写]，见 contracts.md H4）'%(len(ph_hits),','.join(ph_hits)))
if todo_hits and not has_gap_section: fails.append('H-占位符 %d 处 [待填写] 无文末 ## 信息缺口声明 小节'%todo_hits)
print('\n=== 门禁判定 ===')
print('FAIL: '+' / '.join(fails)) if fails else print('PASS: 字数/段落/禁用词/标题策略/注入/占位符 全达标')
