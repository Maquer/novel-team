#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重算 split.py 的 MAP 行号（v1.6 frozen 加了 4 行）。

改动位置（原行号）：
- 1b: 原 line 15 后加原则 4（+1 行）
- 1c: 原 line 60 后加成员不直连（+1 行）
- 2:  原 line 230 后加紧迫感诱导词（+1 行）
- 3:  原 line 477 后加占位符规则（+1 行）

delta 函数：原行号 k 在改动后变成 k + delta(k)
- k < 16:   delta = 0
- 16 <= k < 61:   delta = 1
- 61 <= k < 231:  delta = 2
- 231 <= k < 478: delta = 3
- k >= 478:       delta = 4
"""
import io, re

SPLIT = 'split.py'

def delta(k):
    if k < 16: return 0
    if k < 61: return 1
    if k < 231: return 2
    if k < 478: return 3
    return 4

txt = io.open(SPLIT, encoding='utf-8').read()

# 找到 MAP = [...] 块
m = re.search(r'MAP\s*=\s*\[(.*?)\n\]', txt, re.S)
if not m:
    print('ERROR: 找不到 MAP 块')
    exit(1)

map_body = m.group(1)

# 解析每个条目
entries = re.findall(r"\((\d+)\s*,\s*(\d+)\s*,\s*'([^']+)'\)", map_body)
print('找到 %d 个条目' % len(entries))

new_entries = []
for a, b, t in entries:
    a, b = int(a), int(b)
    new_a = a + delta(a)
    new_b = b + delta(b)
    new_entries.append((new_a, new_b, t))
    if (new_a, new_b) != (a, b):
        print('  (%d,%d,%s) → (%d,%d,%s)' % (a, b, t, new_a, new_b, t))

# 重建 MAP 块
new_map_body = '\n'.join(
    "    (%d, %d, '%s')," % (a, b, t) for a, b, t in new_entries
)
new_map_txt = 'MAP = [\n%s\n]' % new_map_body

# 替换
new_txt = txt[:m.start()] + new_map_txt + txt[m.end():]
io.open(SPLIT, 'w', encoding='utf-8').write(new_txt)
print('split.py 已更新')
