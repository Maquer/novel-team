#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
2026-09-20 v1.6 frozen 更新脚本：
把 3 处规则回写到 frozen 源（原来只落地到脚本 train-check.py + gate-check.py，
但漏写了 docs 层）。改动完成后自动重算 split.py 的 MAP 行号。

3 处改动：
1. overview 段：加"原则 4 意图≠动作" + "门禁硬规则 成员之间不直连"
2. 04-writer 段：加"紧迫感诱导词黑名单"写作纪律
3. contracts 段：加"[待填写] 占位符统一规则"

改动后：
- src/TEAM-v1.5.frozen.md 内容变（文件名保留，语义升 v1.6）
- split.py 的 MAP 行号自动重算
- 跑 split.py 生成新 docs
- 跑 recover.py 同步 bak-pre-split
"""
import io, re, os, sys, shutil

FROZEN = 'src/TEAM-v1.5.frozen.md'
SPLIT = 'split.py'

if not os.path.exists(FROZEN + '.bak-20260920'):
    shutil.copyfile(FROZEN, FROZEN + '.bak-20260920')
    shutil.copyfile(SPLIT, SPLIT + '.bak-20260920')
    print('已备份')

lines = io.open(FROZEN, encoding='utf-8').read().split('\n')
N_old = len(lines)
print('原行数:', N_old)

# ============================================================
# 改动 1: overview 段（原 9-63）
# ============================================================
# 1a. 标题："三条设计原则" → "四条设计原则"
for i, l in enumerate(lines):
    if l.strip() == '## 0. 三条设计原则':
        lines[i] = '## 0. 四条设计原则'
        print('1a. 标题改了 line %d' % (i+1))
        break

# 1b. 原则 4 表格行（在原则 3 后加）
principle4 = '| 4 | **意图 ≠ 动作** | 跨类型任务不等于直接调用某类能力。判定人先看任务类型再定路由，不凭关键词。例："图文需求"不等于直接排稿；"读者反馈"不等于直接回复；"数据"不等于直接下结论 | 错派任务，跳过上游门禁，产出与需求错位 |'
for i, l in enumerate(lines):
    if l.startswith('| 3 | **门禁不可跳过**'):
        lines.insert(i+1, principle4)
        print('1b. 原则 4 加在 line %d 后' % (i+1))
        break

# 1c. 门禁硬规则末尾加"成员不直连"（在"门禁结论一律写进交接物"后）
no_direct = '- **成员之间不直连**：所有跨岗沟通走负责人中转（主笔→排版 / 审核→主笔讨论改法），禁止私下 @ 讨论，避免角色边界退化成口头约定'
for i, l in enumerate(lines):
    if '门禁结论一律写进交接物' in l:
        lines.insert(i+1, no_direct)
        print('1c. 成员不直连 加在 line %d 后' % (i+1))
        break

# ============================================================
# 改动 2: 04-writer 段（原 190-234）加紧迫感诱导词
# ============================================================
urgency_line = '- **不用紧迫感诱导词**：禁用「速看 / 马上删 / 惊呆了 / 震惊 / 必看 / 全网首个 / 全网第一」；弱档参考用「立即 / 紧急 / 限时」在正当语境可用（"立即执行"、"限时优惠"）。要制造紧迫感用**具体数字**（"24 小时内"、"最后一周"）代替抽象紧迫词。对齐微信审核红线（转载会限流），不是审美问题。脚本口径：train-check.py URGENCY 常量已落地。'
for i, l in enumerate(lines):
    if l.startswith('- **删掉所有过渡废话**'):
        lines.insert(i+1, urgency_line)
        print('2. 紧迫感诱导词 加在 line %d 后' % (i+1))
        break

# ============================================================
# 改动 3: contracts 段加 [待填写] 占位符规则
# ============================================================
placeholder_line = '- **占位符统一 `[待填写]`**（H4–H7 契约硬规则）：H4 主笔成稿出现"资料不足"时统一用 `[待填写]`（预期行为，不扣分）。非标占位符（XX / ___ / xxx / 待补 / TBD）= 内容缺陷 = FAIL。出现 `[待填写]` 时必须在文末追加 `## 信息缺口声明` 小节，逐条列出每个占位符的位置/当前状态/补资料计划。脚本口径：gate-check.py 占位符检查已落地。'
for i, l in enumerate(lines):
    if l.startswith('- 一份选题 = 一个目录'):
        lines.insert(i+1, placeholder_line)
        print('3. 占位符规则 加在 line %d 后' % (i+1))
        break

# 写回 frozen
with io.open(FROZEN, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))

N_new = len(lines)
print('新行数:', N_new, '（+%d）' % (N_new - N_old))
