# 主标题（策略：反常识）：一个 4800 星的开源项目，真实项目期只有 4 个月

## 备选标题

1. **一个 4800 星的开源项目，真实项目期只有 4 个月**（反常识）
2. **别再数星了：看 commits 不看 stars**（好奇心缺口）
3. **我用 40 分钟搞清一个"AI 训练神器"其实是空壳**（痛点共鸣）
4. **higgsfield-ai/higgsfield：README 是营销，commits 是现实**（数据冲击）
5. **判断开源项目活跃度的一个反常识方法**（社交货币）

## 元信息

- 平台：微信公众号
- 字数：约 1100 字
- 调性：口语、有立场、有事实锚点

## 正文

我上周想装一个「GitHub 上最新的 LLM 训练编排神器」，仓库名 higgsfield，4800 颗星，Apache-2.0，README 里塞满了 GPU 集群、NCCL、FSDP 这类黑话。

我先按老规矩看星数，4800 星肯定稳。

然后我打开 commits——

44 个 commit，全集中在 2023 年 10 月到 2024 年 2 月之间。**真实项目期只有 4 个月**。之后 28 个月零提交。

GitHub API 显示 pushed_at 是 2026 年 9 月，看着特别新。那是元数据——star 变动、issue 更新都会刷新这个字段，代码没动过。

再往下看，仓库有 460K 字节的 Jupyter Notebook，比 90K 的 Python 代码还多。我以为这是干货，点进去一看，`higgsfield/rl/rl_adventure_2/` 是作者自己另一个 RL 教程仓库的 fork，被直接 merge 进来了。

最讽刺的是 `higgsfield/rl/README.md` 只有 1 行：

> "Soon you'll see the most advanced Reinforcement Learning library for Large Language Models! Stay tuned!"

写下这句是 2023 年 11 月。之后 28 个月，什么都没出来。

一个 4800 星的项目，真实贡献的 Python 代码 90K 字节，一个 placeholder 承诺挂了 2 年多，Jupyter Notebook 460K 字节是个人 RL 教程的 fork——**这不是"活跃"，这是"看起来活跃"**。

再往下看 CI，只有 2 个 workflow，smoketest.yml 里的注释写着 `TODO: compare the generated files`，但没实现。翻译成人话就是：能跑一遍就算过，不判对错。

对比一下真正工程化的项目：archify 有 119 个测试文件 + Node 18-24 四版本矩阵，mdd-sim-gateway 把"曾跳过 15 次的手动检查"直接写进 CI 硬门禁。higgsfield 是"能跑就过"的最低 CI 标准。差别不是工程能力，是作者愿不愿意把"我以为"变成"代码说"。

4 个贡献者：arpanetus 29 个 commit 一个人扛，higgsfield 是公司的机器人账号 8 个，另一个用户 6 个，dependabot 1 个。13 个 open issues 零回复。v0.0.3 从 2024 年 2 月之后一次都没升过。

公司重心早转到 AI 视频生成平台了，这个仓库就是个"曾经想干的事"的墓碑。

我上周还看了个类似的坑：DSHA 版本号倒序，预览版 v1.2.0 比正式版 v0.1.5 更新。avoid-ai-writing 4500 星，PROOF.md 里自己承认 detector 不工作——FPR 4.2% 大于 TPR 7.2%，段落级 ROC-AUC 0.501 等于随机猜测。三种坑形态不同，病根相同。

我在自己 30 个归档项目里翻了翻，发现星数骗人的坑不止 higgsfield 一家：archify 66000 星但 stars:commits 比例异常，DSHA 版本号倒序（预览版比正式版新），avoid-ai-writing 4500 星但 PROOF.md 自己承认 detector 不工作。三种坑形态不同，病根相同——**README 是营销声明，commits 是现实**。

以后判断一个仓库值不值得装，别看星数，不看 pushed_at，不看 README 里写了多少黑话。看 4 个东西：

第一，最后一笔实质性代码 commit 是什么时候。不是 GitHub 显示的 last push，是最后改过实际源码的 commit。

第二，Jupyter Notebook / 演示文档占字节的比例。占比高说明是 fork 或个人教程撑起来的假活跃。

第三，README 里有没有"Stay tuned"、"coming soon"这类没兑现的承诺。有就划等号于 placeholder。

第四，CI 里有没有真正的断言。TODO 明写"compare but not implemented" 就是空壳。

这个判断法 30 秒能做完，比读完一篇 README 快多了。**别再数星了。数 commits。**

我自己记了个更简单的判断法：任何 4000 星以上的开源项目，先翻 3 笔最近的 commit，看有没有实际代码改动。全在改 README、改 CI、改文档、只是 dependabot 的依赖升级——那就是空壳，直接跳过。

4800 星不代表 4800 个真用户，可能只是 4 个人的个人实验挂在公司账号下、被 SEO 和推文刷出来的数字。GitHub 上有 100 多个类似案例，我只归档了 30 个。**星数是营销，commits 才是产品。**

## AI 参与

本文数据（4814 星 / 892 fork / 4 贡献者 / 44 commits / 28 个月零提交 / Jupyter 460K vs Python 90K / smoketest.yml TODO 内容）来自 2026-09-20 的 GitHub API 实测 + shallow clone 全 24 个 py 文件 + 2 个 workflow + pyproject.toml。文风由 gzh-team 主笔岗 + 审核岗（10 项门禁）共同保证。
